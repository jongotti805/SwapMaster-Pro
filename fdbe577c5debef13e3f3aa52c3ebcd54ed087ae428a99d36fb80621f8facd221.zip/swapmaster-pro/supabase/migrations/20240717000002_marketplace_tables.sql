-- Add missing essential tables for SwapMaster Pro marketplace

-- Product categories
CREATE TABLE IF NOT EXISTS product_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    parent_id UUID REFERENCES product_categories(id),
    icon_url TEXT,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Products/Parts for marketplace
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    seller_id UUID NOT NULL, -- Reference to auth.users
    category_id UUID REFERENCES product_categories(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    original_price DECIMAL(10,2),
    condition VARCHAR(20) DEFAULT 'used', -- 'new', 'used', 'refurbished'
    brand VARCHAR(100),
    part_number VARCHAR(100),
    compatibility JSONB DEFAULT '{}', -- Vehicle compatibility info
    location VARCHAR(100),
    shipping_cost DECIMAL(10,2) DEFAULT 0,
    quantity INTEGER DEFAULT 1,
    images TEXT[], -- Array of image URLs
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'sold', 'pending', 'inactive'
    views_count INTEGER DEFAULT 0,
    is_featured BOOLEAN DEFAULT false,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Reviews for products/sellers
CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    reviewer_id UUID NOT NULL, -- Reference to auth.users
    seller_id UUID NOT NULL, -- Reference to auth.users
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    verified_purchase BOOLEAN DEFAULT false,
    helpful_count INTEGER DEFAULT 0,
    images TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User vehicles
CREATE TABLE IF NOT EXISTS user_vehicles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL, -- Reference to auth.users
    name VARCHAR(100), -- User-given name like "My Project Car"
    year INTEGER NOT NULL,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    trim VARCHAR(50),
    engine VARCHAR(100),
    transmission VARCHAR(100),
    current_mods TEXT[],
    planned_mods TEXT[],
    images TEXT[],
    is_primary BOOLEAN DEFAULT false,
    is_public BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Messages table (if not exists)
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL, -- Reference to chat_rooms
    sender_id UUID NOT NULL, -- Reference to auth.users
    content TEXT NOT NULL,
    message_type VARCHAR(20) DEFAULT 'text', -- 'text', 'image', 'file', 'system'
    file_url TEXT,
    file_name TEXT,
    file_size INTEGER,
    reply_to UUID REFERENCES messages(id),
    is_edited BOOLEAN DEFAULT false,
    edited_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default product categories
INSERT INTO product_categories (name, description, sort_order) VALUES
('Engine', 'Complete engines, engine components, and internals', 1),
('Transmission', 'Manual and automatic transmissions, clutches, and components', 2),
('Suspension', 'Coilovers, springs, shocks, struts, and handling components', 3),
('Brakes', 'Brake pads, rotors, calipers, and brake system components', 4),
('Exhaust', 'Headers, cat-back systems, mufflers, and exhaust components', 5),
('Electrical', 'Wiring, ECUs, sensors, and electrical components', 6),
('Interior', 'Seats, steering wheels, gauges, and interior modifications', 7),
('Exterior', 'Body kits, wheels, tires, and exterior styling', 8),
('Tools', 'Specialty tools and equipment for automotive work', 9),
('Other', 'Miscellaneous automotive parts and accessories', 10)
ON CONFLICT (name) DO NOTHING;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_products_seller_id ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at);
CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewer_id ON reviews(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_user_vehicles_user_id ON user_vehicles(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_room_id ON messages(room_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- Add triggers for updated_at columns
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_user_vehicles_updated_at BEFORE UPDATE ON user_vehicles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();