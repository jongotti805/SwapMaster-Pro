-- SwapMaster Pro Professional Accounts Schema
-- Tables for professional accounts and business analytics

CREATE TABLE IF NOT EXISTS professional_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
    business_name VARCHAR(200) NOT NULL,
    business_type VARCHAR(100) NOT NULL,
    business_address TEXT,
    phone VARCHAR(20),
    website VARCHAR(200),
    specialties TEXT[] DEFAULT '{}',
    hourly_rate DECIMAL(8,2) DEFAULT 0,
    certification_level VARCHAR(50) DEFAULT 'standard',
    years_experience INTEGER DEFAULT 0,
    team_size INTEGER DEFAULT 1,
    is_verified BOOLEAN DEFAULT false,
    verification_documents JSONB DEFAULT '{}',
    business_hours JSONB DEFAULT '{}',
    service_radius_miles INTEGER DEFAULT 50,
    insurance_info JSONB DEFAULT '{}',
    portfolio_images TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customer_projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    professional_id UUID REFERENCES professional_accounts(id) ON DELETE CASCADE,
    customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    project_name VARCHAR(200) NOT NULL,
    project_description TEXT,
    project_type VARCHAR(100) NOT NULL,
    vehicle_info JSONB DEFAULT '{}',
    target_specs JSONB DEFAULT '{}',
    project_status VARCHAR(50) DEFAULT 'quoted',
    estimated_cost DECIMAL(10,2) DEFAULT 0,
    actual_cost DECIMAL(10,2) DEFAULT 0,
    estimated_duration_days INTEGER DEFAULT 0,
    actual_duration_days INTEGER DEFAULT 0,
    progress_percentage INTEGER DEFAULT 0,
    start_date DATE,
    completion_date DATE,
    customer_satisfaction_rating INTEGER CHECK (customer_satisfaction_rating >= 1 AND customer_satisfaction_rating <= 5),
    project_notes TEXT,
    parts_list JSONB DEFAULT '[]',
    labor_breakdown JSONB DEFAULT '{}',
    images TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS project_updates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID REFERENCES customer_projects(id) ON DELETE CASCADE,
    update_type VARCHAR(50) NOT NULL,
    title VARCHAR(200),
    description TEXT NOT NULL,
    progress_percentage INTEGER,
    images TEXT[] DEFAULT '{}',
    parts_used JSONB DEFAULT '[]',
    time_spent_hours DECIMAL(6,2) DEFAULT 0,
    cost_incurred DECIMAL(8,2) DEFAULT 0,
    is_milestone BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS professional_certifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    professional_id UUID REFERENCES professional_accounts(id) ON DELETE CASCADE,
    certification_name VARCHAR(200) NOT NULL,
    issuing_organization VARCHAR(200) NOT NULL,
    certification_number VARCHAR(100),
    issue_date DATE,
    expiry_date DATE,
    verification_status VARCHAR(50) DEFAULT 'pending',
    document_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS business_analytics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    professional_id UUID REFERENCES professional_accounts(id) ON DELETE CASCADE,
    metric_date DATE NOT NULL,
    total_revenue DECIMAL(12,2) DEFAULT 0,
    total_projects INTEGER DEFAULT 0,
    active_projects INTEGER DEFAULT 0,
    completed_projects INTEGER DEFAULT 0,
    avg_project_value DECIMAL(10,2) DEFAULT 0,
    avg_customer_satisfaction DECIMAL(3,2) DEFAULT 0,
    conversion_rate DECIMAL(5,2) DEFAULT 0,
    repeat_customer_rate DECIMAL(5,2) DEFAULT 0,
    lead_sources JSONB DEFAULT '{}',
    service_breakdown JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(professional_id, metric_date)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_professional_accounts_user_id ON professional_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_professional_accounts_verified ON professional_accounts(is_verified);
CREATE INDEX IF NOT EXISTS idx_professional_accounts_location ON professional_accounts(business_address);
CREATE INDEX IF NOT EXISTS idx_professional_accounts_specialties ON professional_accounts USING GIN(specialties);

CREATE INDEX IF NOT EXISTS idx_customer_projects_professional ON customer_projects(professional_id);
CREATE INDEX IF NOT EXISTS idx_customer_projects_customer ON customer_projects(customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_projects_status ON customer_projects(project_status);
CREATE INDEX IF NOT EXISTS idx_customer_projects_dates ON customer_projects(start_date, completion_date);

CREATE INDEX IF NOT EXISTS idx_project_updates_project ON project_updates(project_id);
CREATE INDEX IF NOT EXISTS idx_project_updates_type ON project_updates(update_type);
CREATE INDEX IF NOT EXISTS idx_project_updates_date ON project_updates(created_at);

CREATE INDEX IF NOT EXISTS idx_professional_certifications_professional ON professional_certifications(professional_id);
CREATE INDEX IF NOT EXISTS idx_professional_certifications_status ON professional_certifications(verification_status);

CREATE INDEX IF NOT EXISTS idx_business_analytics_professional ON business_analytics(professional_id);
CREATE INDEX IF NOT EXISTS idx_business_analytics_date ON business_analytics(metric_date);

-- Add triggers
CREATE TRIGGER update_professional_accounts_updated_at BEFORE UPDATE ON professional_accounts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_customer_projects_updated_at BEFORE UPDATE ON customer_projects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE professional_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE professional_certifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Professional accounts are viewable by verified professionals" ON professional_accounts
    FOR SELECT USING (is_verified = true OR auth.uid() = user_id);
    
CREATE POLICY "Users can create their professional account" ON professional_accounts
    FOR INSERT WITH CHECK (auth.uid() = user_id);
    
CREATE POLICY "Users can update their own professional account" ON professional_accounts
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Projects viewable by professional and customer" ON customer_projects
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM professional_accounts WHERE id = professional_id AND user_id = auth.uid())
        OR customer_id = auth.uid()
    );
    
CREATE POLICY "Professionals can create projects" ON customer_projects
    FOR INSERT WITH CHECK (
        EXISTS (SELECT 1 FROM professional_accounts WHERE id = professional_id AND user_id = auth.uid())
    );
    
CREATE POLICY "Professionals can update their projects" ON customer_projects
    FOR UPDATE USING (
        EXISTS (SELECT 1 FROM professional_accounts WHERE id = professional_id AND user_id = auth.uid())
    );

CREATE POLICY "Project updates viewable by project participants" ON project_updates
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM customer_projects cp
            JOIN professional_accounts pa ON cp.professional_id = pa.id
            WHERE cp.id = project_id AND (pa.user_id = auth.uid() OR cp.customer_id = auth.uid())
        )
    );
    
CREATE POLICY "Professionals can create project updates" ON project_updates
    FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM customer_projects cp
            JOIN professional_accounts pa ON cp.professional_id = pa.id
            WHERE cp.id = project_id AND pa.user_id = auth.uid()
        )
    );

CREATE POLICY "Professionals can view their certifications" ON professional_certifications
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM professional_accounts WHERE id = professional_id AND user_id = auth.uid())
    );
    
CREATE POLICY "Professionals can manage their certifications" ON professional_certifications
    FOR ALL USING (
        EXISTS (SELECT 1 FROM professional_accounts WHERE id = professional_id AND user_id = auth.uid())
    );

CREATE POLICY "Professionals can view their analytics" ON business_analytics
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM professional_accounts WHERE id = professional_id AND user_id = auth.uid())
    );

-- Function to calculate business analytics
CREATE OR REPLACE FUNCTION calculate_business_analytics(prof_id UUID, calc_date DATE)
RETURNS VOID AS $$
BEGIN
    INSERT INTO business_analytics (
        professional_id,
        metric_date,
        total_revenue,
        total_projects,
        active_projects,
        completed_projects,
        avg_project_value,
        avg_customer_satisfaction,
        conversion_rate
    )
    SELECT 
        prof_id,
        calc_date,
        COALESCE(SUM(actual_cost), 0) as total_revenue,
        COUNT(*) as total_projects,
        COUNT(*) FILTER (WHERE project_status IN ('in_progress', 'approved')) as active_projects,
        COUNT(*) FILTER (WHERE project_status = 'completed') as completed_projects,
        COALESCE(AVG(actual_cost), 0) as avg_project_value,
        COALESCE(AVG(customer_satisfaction_rating), 0) as avg_customer_satisfaction,
        CASE 
            WHEN COUNT(*) > 0 THEN (COUNT(*) FILTER (WHERE project_status != 'cancelled')::DECIMAL / COUNT(*) * 100)
            ELSE 0
        END as conversion_rate
    FROM customer_projects
    WHERE professional_id = prof_id
      AND created_at::DATE <= calc_date
    GROUP BY professional_id
    ON CONFLICT (professional_id, metric_date)
    DO UPDATE SET
        total_revenue = EXCLUDED.total_revenue,
        total_projects = EXCLUDED.total_projects,
        active_projects = EXCLUDED.active_projects,
        completed_projects = EXCLUDED.completed_projects,
        avg_project_value = EXCLUDED.avg_project_value,
        avg_customer_satisfaction = EXCLUDED.avg_customer_satisfaction,
        conversion_rate = EXCLUDED.conversion_rate;
END;
$$ LANGUAGE plpgsql;