-- SwapMaster Pro Swap Reviews Schema
-- Tables for community reviews and ratings of engine swaps

-- Swap reviews table
CREATE TABLE IF NOT EXISTS swap_reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    reviewer_name VARCHAR(100) NOT NULL,
    reviewer_avatar TEXT,
    vehicle_year INTEGER NOT NULL,
    vehicle_make VARCHAR(50) NOT NULL,
    vehicle_model VARCHAR(50) NOT NULL,
    engine_name VARCHAR(100) NOT NULL,
    engine_make VARCHAR(50) NOT NULL,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5) NOT NULL,
    difficulty_rating INTEGER CHECK (difficulty_rating >= 1 AND difficulty_rating <= 5) NOT NULL DEFAULT 3,
    cost_rating INTEGER CHECK (cost_rating >= 1 AND cost_rating <= 5) NOT NULL DEFAULT 3,
    title VARCHAR(200) NOT NULL,
    review_text TEXT NOT NULL,
    pros TEXT[] DEFAULT '{}',
    cons TEXT[] DEFAULT '{}',
    actual_cost DECIMAL(10,2) DEFAULT 0,
    time_taken_hours DECIMAL(8,2) DEFAULT 0,
    would_recommend BOOLEAN DEFAULT true,
    images TEXT[] DEFAULT '{}',
    helpful_count INTEGER DEFAULT 0,
    tags TEXT[] DEFAULT '{}',
    swap_status VARCHAR(20) DEFAULT 'completed' CHECK (swap_status IN ('completed', 'in_progress', 'planning')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Review helpful tracking table
CREATE TABLE IF NOT EXISTS review_helpful (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    review_id UUID REFERENCES swap_reviews(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, review_id)
);

-- Swap compatibility ratings (aggregated community data)
CREATE TABLE IF NOT EXISTS swap_compatibility_ratings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_make VARCHAR(50) NOT NULL,
    vehicle_model VARCHAR(50) NOT NULL,
    vehicle_year_min INTEGER,
    vehicle_year_max INTEGER,
    engine_name VARCHAR(100) NOT NULL,
    engine_make VARCHAR(50) NOT NULL,
    avg_rating DECIMAL(3,2) DEFAULT 0,
    avg_difficulty DECIMAL(3,2) DEFAULT 0,
    avg_cost_rating DECIMAL(3,2) DEFAULT 0,
    total_reviews INTEGER DEFAULT 0,
    recommendation_percentage DECIMAL(5,2) DEFAULT 0,
    avg_actual_cost DECIMAL(10,2) DEFAULT 0,
    avg_time_hours DECIMAL(8,2) DEFAULT 0,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(vehicle_make, vehicle_model, engine_make, engine_name)
);

-- Professional installer reviews
CREATE TABLE IF NOT EXISTS installer_reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    installer_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    customer_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    swap_review_id UUID REFERENCES swap_reviews(id),
    installer_rating INTEGER CHECK (installer_rating >= 1 AND installer_rating <= 5) NOT NULL,
    quality_rating INTEGER CHECK (quality_rating >= 1 AND quality_rating <= 5) NOT NULL,
    timeliness_rating INTEGER CHECK (timeliness_rating >= 1 AND timeliness_rating <= 5) NOT NULL,
    communication_rating INTEGER CHECK (communication_rating >= 1 AND communication_rating <= 5) NOT NULL,
    value_rating INTEGER CHECK (value_rating >= 1 AND value_rating <= 5) NOT NULL,
    review_title VARCHAR(200),
    review_text TEXT,
    would_recommend_installer BOOLEAN DEFAULT true,
    project_cost DECIMAL(10,2),
    project_duration_days INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_swap_reviews_user_id ON swap_reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_swap_reviews_vehicle ON swap_reviews(vehicle_make, vehicle_model, vehicle_year);
CREATE INDEX IF NOT EXISTS idx_swap_reviews_engine ON swap_reviews(engine_make, engine_name);
CREATE INDEX IF NOT EXISTS idx_swap_reviews_rating ON swap_reviews(rating);
CREATE INDEX IF NOT EXISTS idx_swap_reviews_created_at ON swap_reviews(created_at);
CREATE INDEX IF NOT EXISTS idx_swap_reviews_status ON swap_reviews(swap_status);
CREATE INDEX IF NOT EXISTS idx_swap_reviews_helpful ON swap_reviews(helpful_count);

CREATE INDEX IF NOT EXISTS idx_review_helpful_user_review ON review_helpful(user_id, review_id);
CREATE INDEX IF NOT EXISTS idx_review_helpful_review_id ON review_helpful(review_id);

CREATE INDEX IF NOT EXISTS idx_compatibility_ratings_vehicle ON swap_compatibility_ratings(vehicle_make, vehicle_model);
CREATE INDEX IF NOT EXISTS idx_compatibility_ratings_engine ON swap_compatibility_ratings(engine_make, engine_name);
CREATE INDEX IF NOT EXISTS idx_compatibility_ratings_rating ON swap_compatibility_ratings(avg_rating);

CREATE INDEX IF NOT EXISTS idx_installer_reviews_installer ON installer_reviews(installer_user_id);
CREATE INDEX IF NOT EXISTS idx_installer_reviews_customer ON installer_reviews(customer_user_id);
CREATE INDEX IF NOT EXISTS idx_installer_reviews_rating ON installer_reviews(installer_rating);

-- Add trigger for updated_at column
CREATE TRIGGER update_swap_reviews_updated_at BEFORE UPDATE ON swap_reviews
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security (RLS)
ALTER TABLE swap_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE review_helpful ENABLE ROW LEVEL SECURITY;
ALTER TABLE swap_compatibility_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE installer_reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- Swap reviews: viewable by all, editable by owner
CREATE POLICY "Swap reviews are viewable by everyone" ON swap_reviews
    FOR SELECT USING (true);
    
CREATE POLICY "Users can create swap reviews" ON swap_reviews
    FOR INSERT WITH CHECK (auth.uid() = user_id);
    
CREATE POLICY "Users can update their own swap reviews" ON swap_reviews
    FOR UPDATE USING (auth.uid() = user_id);

-- Review helpful: users can mark reviews as helpful
CREATE POLICY "Users can view helpful marks" ON review_helpful
    FOR SELECT USING (true);
    
CREATE POLICY "Users can mark reviews as helpful" ON review_helpful
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Compatibility ratings: viewable by all
CREATE POLICY "Compatibility ratings are viewable by everyone" ON swap_compatibility_ratings
    FOR SELECT USING (true);

-- Installer reviews: viewable by all, customer can create
CREATE POLICY "Installer reviews are viewable by everyone" ON installer_reviews
    FOR SELECT USING (true);
    
CREATE POLICY "Customers can create installer reviews" ON installer_reviews
    FOR INSERT WITH CHECK (auth.uid() = customer_user_id);

-- Function to update compatibility ratings (called after review insert/update)
CREATE OR REPLACE FUNCTION update_compatibility_ratings()
RETURNS TRIGGER AS $$
BEGIN
    -- Update or insert compatibility rating aggregate
    INSERT INTO swap_compatibility_ratings (
        vehicle_make,
        vehicle_model,
        vehicle_year_min,
        vehicle_year_max,
        engine_name,
        engine_make,
        avg_rating,
        avg_difficulty,
        avg_cost_rating,
        total_reviews,
        recommendation_percentage,
        avg_actual_cost,
        avg_time_hours,
        last_updated
    )
    SELECT 
        NEW.vehicle_make,
        NEW.vehicle_model,
        MIN(vehicle_year),
        MAX(vehicle_year),
        NEW.engine_name,
        NEW.engine_make,
        AVG(rating::DECIMAL),
        AVG(difficulty_rating::DECIMAL),
        AVG(cost_rating::DECIMAL),
        COUNT(*),
        (COUNT(*) FILTER (WHERE would_recommend = true)::DECIMAL / COUNT(*) * 100),
        AVG(actual_cost),
        AVG(time_taken_hours),
        NOW()
    FROM swap_reviews 
    WHERE vehicle_make = NEW.vehicle_make 
      AND vehicle_model = NEW.vehicle_model
      AND engine_name = NEW.engine_name 
      AND engine_make = NEW.engine_make
    GROUP BY vehicle_make, vehicle_model, engine_name, engine_make
    ON CONFLICT (vehicle_make, vehicle_model, engine_make, engine_name)
    DO UPDATE SET
        vehicle_year_min = EXCLUDED.vehicle_year_min,
        vehicle_year_max = EXCLUDED.vehicle_year_max,
        avg_rating = EXCLUDED.avg_rating,
        avg_difficulty = EXCLUDED.avg_difficulty,
        avg_cost_rating = EXCLUDED.avg_cost_rating,
        total_reviews = EXCLUDED.total_reviews,
        recommendation_percentage = EXCLUDED.recommendation_percentage,
        avg_actual_cost = EXCLUDED.avg_actual_cost,
        avg_time_hours = EXCLUDED.avg_time_hours,
        last_updated = EXCLUDED.last_updated;
        
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update compatibility ratings when reviews are added/updated
CREATE TRIGGER update_compatibility_ratings_trigger
    AFTER INSERT OR UPDATE ON swap_reviews
    FOR EACH ROW EXECUTE FUNCTION update_compatibility_ratings();

-- Sample data for testing
INSERT INTO swap_reviews (
    user_id,
    reviewer_name,
    vehicle_year,
    vehicle_make,
    vehicle_model,
    engine_name,
    engine_make,
    rating,
    difficulty_rating,
    cost_rating,
    title,
    review_text,
    pros,
    cons,
    actual_cost,
    time_taken_hours,
    would_recommend,
    helpful_count,
    tags,
    swap_status
) VALUES 
(
    '00000000-0000-0000-0000-000000000001',
    'Sample User',
    2010,
    'BMW',
    'E46',
    'LS3',
    'Chevrolet',
    5,
    4,
    3,
    'Amazing LS3 swap in E46',
    'Completed my LS3 swap in my E46 and it is absolutely incredible. The power delivery is smooth and the sound is perfect.',
    ARRAY['Incredible power', 'Great sound', 'Reliable engine', 'Good aftermarket support'],
    ARRAY['Expensive initial cost', 'Complex wiring', 'Required custom fabrication'],
    12500.00,
    65.0,
    true,
    15,
    ARRAY['ls-swap', 'bmw', 'performance'],
    'completed'
),
(
    '00000000-0000-0000-0000-000000000002',
    'Pro Mechanic',
    2015,
    'Toyota',
    'GT86',
    '2JZ-GTE',
    'Toyota',
    4,
    5,
    4,
    'Professional 2JZ swap - challenging but worth it',
    'This was one of the most challenging swaps I have done professionally. Required extensive custom work but the results are incredible.',
    ARRAY['Legendary engine', 'Huge tuning potential', 'Perfect for drag racing'],
    ARRAY['Very complex install', 'Expensive parts', 'Requires professional expertise'],
    18000.00,
    80.0,
    true,
    8,
    ARRAY['2jz-swap', 'toyota', 'professional', 'turbo'],
    'completed'
)
ON CONFLICT DO NOTHING;