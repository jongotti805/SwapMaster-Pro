-- SwapMaster Pro Credit Plans Schema
-- Tables for managing credit packages and purchases

CREATE TABLE IF NOT EXISTS gearshift_plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plan_type VARCHAR(50) UNIQUE NOT NULL,
    plan_name VARCHAR(100) NOT NULL,
    description TEXT,
    credits INTEGER NOT NULL DEFAULT 0,
    price INTEGER NOT NULL, -- Price in cents
    is_subscription BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    features JSONB DEFAULT '{}',
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS gearshift_subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    stripe_subscription_id VARCHAR(100) UNIQUE,
    stripe_customer_id VARCHAR(100),
    price_id VARCHAR(100),
    status VARCHAR(50) DEFAULT 'active',
    current_period_start TIMESTAMP WITH TIME ZONE,
    current_period_end TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert credit plans
INSERT INTO gearshift_plans (plan_type, plan_name, description, credits, price, discount_percentage, features, sort_order)
VALUES 
('500_credits', '500 Credits Pack', 'Perfect for casual users and occasional professionals', 500, 4000, 20.0, 
 '{"bulk_discount": true, "priority_support": false, "advanced_features": false}', 1),

('1000_credits', '1000 Credits Pack', 'Great for regular users and small shops', 1000, 7500, 25.0,
 '{"bulk_discount": true, "priority_support": true, "advanced_features": false}', 2),

('5000_credits', '5000 Credits Pack', 'Best value for professional shops and heavy users', 5000, 28000, 30.0,
 '{"bulk_discount": true, "priority_support": true, "advanced_features": true}', 3)

ON CONFLICT (plan_type) DO UPDATE SET
    plan_name = EXCLUDED.plan_name,
    description = EXCLUDED.description,
    credits = EXCLUDED.credits,
    price = EXCLUDED.price,
    discount_percentage = EXCLUDED.discount_percentage,
    features = EXCLUDED.features,
    sort_order = EXCLUDED.sort_order,
    updated_at = NOW();

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_gearshift_plans_active ON gearshift_plans(is_active);
CREATE INDEX IF NOT EXISTS idx_gearshift_plans_type ON gearshift_plans(plan_type);
CREATE INDEX IF NOT EXISTS idx_gearshift_subscriptions_user ON gearshift_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_gearshift_subscriptions_stripe ON gearshift_subscriptions(stripe_subscription_id);
CREATE INDEX IF NOT EXISTS idx_gearshift_subscriptions_status ON gearshift_subscriptions(status);

-- Add trigger for updated_at
CREATE TRIGGER update_gearshift_plans_updated_at BEFORE UPDATE ON gearshift_plans
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_gearshift_subscriptions_updated_at BEFORE UPDATE ON gearshift_subscriptions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE gearshift_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE gearshift_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Plans are viewable by everyone" ON gearshift_plans
    FOR SELECT USING (is_active = true);
    
CREATE POLICY "Users can view their own subscriptions" ON gearshift_subscriptions
    FOR SELECT USING (auth.uid() = user_id);