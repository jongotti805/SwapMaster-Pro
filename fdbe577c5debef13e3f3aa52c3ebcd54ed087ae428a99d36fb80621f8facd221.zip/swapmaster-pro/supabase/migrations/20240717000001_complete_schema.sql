-- SwapMaster Pro Complete Database Schema
-- Additional tables for chat, marketplace, and user features

-- User profiles extension
CREATE TABLE IF NOT EXISTS user_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    username VARCHAR(50) UNIQUE,
    full_name VARCHAR(100),
    bio TEXT,
    location VARCHAR(100),
    avatar_url TEXT,
    phone VARCHAR(20),
    website_url TEXT,
    years_of_experience INTEGER DEFAULT 0,
    specialties TEXT[], -- Array of specialties like ['Engine Swaps', 'Suspension', 'Electrical']
    verification_status VARCHAR(20) DEFAULT 'unverified', -- 'unverified', 'verified', 'expert'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Chat rooms
CREATE TABLE IF NOT EXISTS chat_rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    room_type VARCHAR(20) DEFAULT 'public', -- 'public', 'private', 'group'
    created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    max_participants INTEGER DEFAULT 100,
    is_active BOOLEAN DEFAULT true,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Chat room participants
CREATE TABLE IF NOT EXISTS chat_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES chat_rooms(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    role VARCHAR(20) DEFAULT 'member', -- 'admin', 'moderator', 'member'
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_muted BOOLEAN DEFAULT false,
    UNIQUE(room_id, user_id)
);

-- Messages
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES chat_rooms(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    message_type VARCHAR(20) DEFAULT 'text', -- 'text', 'image', 'file', 'system'
    file_url TEXT,
    file_name TEXT,
    file_size INTEGER,
    reply_to UUID REFERENCES messages(id),
    is_edited BOOLEAN DEFAULT false,
    edited_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Product categories
CREATE TABLE IF NOT EXISTS product_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    parent_id UUID REFERENCES product_categories(id),
    icon_url TEXT,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Products/Parts for marketplace
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    seller_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    category_id UUID REFERENCES product_categories(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    original_price DECIMAL(10,2),
    condition VARCHAR(20) DEFAULT 'used', -- 'new', 'used', 'refurbished'
    brand VARCHAR(100),
    part_number VARCHAR(100),
    compatibility JSONB DEFAULT '{}', -- Vehicle compatibility info
    location VARCHAR(100),
    shipping_cost DECIMAL(10,2) DEFAULT 0,
    quantity INTEGER DEFAULT 1,
    images TEXT[], -- Array of image URLs
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'sold', 'pending', 'inactive'
    views_count INTEGER DEFAULT 0,
    is_featured BOOLEAN DEFAULT false,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Reviews for products/sellers
CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    reviewer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    seller_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    verified_purchase BOOLEAN DEFAULT false,
    helpful_count INTEGER DEFAULT 0,
    images TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User wishlists
CREATE TABLE IF NOT EXISTS wishlists (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    notes TEXT,
    priority INTEGER DEFAULT 1, -- 1=low, 2=medium, 3=high
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, product_id)
);

-- Shopping cart
CREATE TABLE IF NOT EXISTS shopping_cart (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    quantity INTEGER DEFAULT 1,
    added_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, product_id)
);

-- Part recommendations (from AI)
CREATE TABLE IF NOT EXISTS part_recommendations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    part_id VARCHAR(100) NOT NULL,
    recommendation_type VARCHAR(50) NOT NULL, -- 'compatibility', 'upgrade', 'alternative'
    score DECIMAL(3,2) CHECK (score >= 0 AND score <= 1), -- 0.0 to 1.0
    reasoning TEXT,
    metadata JSONB DEFAULT '{}',
    expires_at TIMESTAMP WITH TIME ZONE,
    is_dismissed BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User vehicles
CREATE TABLE IF NOT EXISTS user_vehicles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(100), -- User-given name like "My Project Car"
    year INTEGER NOT NULL,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    trim VARCHAR(50),
    engine VARCHAR(100),
    transmission VARCHAR(100),
    current_mods TEXT[],
    planned_mods TEXT[],
    images TEXT[],
    is_primary BOOLEAN DEFAULT false,
    is_public BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default product categories
INSERT INTO product_categories (name, description, sort_order) VALUES
('Engine', 'Complete engines, engine components, and internals', 1),
('Transmission', 'Manual and automatic transmissions, clutches, and components', 2),
('Suspension', 'Coilovers, springs, shocks, struts, and handling components', 3),
('Brakes', 'Brake pads, rotors, calipers, and brake system components', 4),
('Exhaust', 'Headers, cat-back systems, mufflers, and exhaust components', 5),
('Electrical', 'Wiring, ECUs, sensors, and electrical components', 6),
('Interior', 'Seats, steering wheels, gauges, and interior modifications', 7),
('Exterior', 'Body kits, wheels, tires, and exterior styling', 8),
('Tools', 'Specialty tools and equipment for automotive work', 9),
('Other', 'Miscellaneous automotive parts and accessories', 10)
ON CONFLICT (name) DO NOTHING;

-- Insert default chat rooms
INSERT INTO chat_rooms (name, description, room_type) VALUES
('General Discussion', 'General automotive discussion and help', 'public'),
('Engine Swaps', 'Everything about engine swaps and conversions', 'public'),
('Project Showcase', 'Show off your builds and get feedback', 'public'),
('Buy/Sell/Trade', 'Marketplace discussions and part sourcing', 'public'),
('Tech Support', 'Technical questions and troubleshooting help', 'public')
ON CONFLICT DO NOTHING;

-- Create additional indexes
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_username ON user_profiles(username);
CREATE INDEX IF NOT EXISTS idx_chat_participants_room_user ON chat_participants(room_id, user_id);
CREATE INDEX IF NOT EXISTS idx_messages_room_id ON messages(room_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
CREATE INDEX IF NOT EXISTS idx_products_seller_id ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at);
CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewer_id ON reviews(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_wishlists_user_id ON wishlists(user_id);
CREATE INDEX IF NOT EXISTS idx_shopping_cart_user_id ON shopping_cart(user_id);
CREATE INDEX IF NOT EXISTS idx_part_recommendations_user_id ON part_recommendations(user_id);
CREATE INDEX IF NOT EXISTS idx_user_vehicles_user_id ON user_vehicles(user_id);

-- Add triggers for updated_at columns
CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_chat_rooms_updated_at BEFORE UPDATE ON chat_rooms
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_user_vehicles_updated_at BEFORE UPDATE ON user_vehicles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security (RLS)
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE shopping_cart ENABLE ROW LEVEL SECURITY;
ALTER TABLE part_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_vehicles ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- User profiles: users can view all profiles, but only edit their own
CREATE POLICY "Public profiles are viewable by everyone" ON user_profiles
    FOR SELECT USING (true);
    
CREATE POLICY "Users can insert their own profile" ON user_profiles
    FOR INSERT WITH CHECK (auth.uid() = user_id);
    
CREATE POLICY "Users can update their own profile" ON user_profiles
    FOR UPDATE USING (auth.uid() = user_id);

-- Chat rooms: public rooms viewable by all, private rooms by participants
CREATE POLICY "Public chat rooms are viewable by everyone" ON chat_rooms
    FOR SELECT USING (room_type = 'public' OR created_by = auth.uid());

-- Messages: viewable by room participants
CREATE POLICY "Messages viewable by room participants" ON messages
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM chat_participants 
            WHERE chat_participants.room_id = messages.room_id 
            AND chat_participants.user_id = auth.uid()
        )
    );
    
CREATE POLICY "Users can send messages to rooms they're in" ON messages
    FOR INSERT WITH CHECK (
        auth.uid() = sender_id AND
        EXISTS (
            SELECT 1 FROM chat_participants 
            WHERE chat_participants.room_id = messages.room_id 
            AND chat_participants.user_id = auth.uid()
        )
    );

-- Products: all products viewable, sellers can manage their own
CREATE POLICY "Products are viewable by everyone" ON products
    FOR SELECT USING (status = 'active' OR seller_id = auth.uid());
    
CREATE POLICY "Users can insert their own products" ON products
    FOR INSERT WITH CHECK (auth.uid() = seller_id);
    
CREATE POLICY "Users can update their own products" ON products
    FOR UPDATE USING (auth.uid() = seller_id);

-- Reviews: viewable by all, users can create/edit their own
CREATE POLICY "Reviews are viewable by everyone" ON reviews
    FOR SELECT USING (true);
    
CREATE POLICY "Users can create reviews" ON reviews
    FOR INSERT WITH CHECK (auth.uid() = reviewer_id);

-- Wishlists and cart: users can only access their own
CREATE POLICY "Users can manage their own wishlist" ON wishlists
    FOR ALL USING (auth.uid() = user_id);
    
CREATE POLICY "Users can manage their own cart" ON shopping_cart
    FOR ALL USING (auth.uid() = user_id);
    
CREATE POLICY "Users can view their own recommendations" ON part_recommendations
    FOR SELECT USING (auth.uid() = user_id);
    
CREATE POLICY "Users can manage their own vehicles" ON user_vehicles
    FOR ALL USING (auth.uid() = user_id);