-- Add user credits function for Stripe webhooks

CREATE OR REPLACE FUNCTION add_user_credits(user_id_param UUID, credits_to_add INTEGER)
RETURNS VOID AS $$
BEGIN
    -- Insert or update user credits
    INSERT INTO user_credits (user_id, credits_remaining, total_credits_purchased)
    VALUES (user_id_param, credits_to_add, credits_to_add)
    ON CONFLICT (user_id)
    DO UPDATE SET
        credits_remaining = user_credits.credits_remaining + credits_to_add,
        total_credits_purchased = user_credits.total_credits_purchased + credits_to_add,
        updated_at = NOW();
        
    -- Log the credit purchase
    INSERT INTO credit_transactions (user_id, transaction_type, amount, description)
    VALUES (user_id_param, 'purchase', credits_to_add, 'Credit purchase via Stripe');
END;
$$ LANGUAGE plpgsql;