-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Vendors table
CREATE TABLE IF NOT EXISTS vendors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    website_url TEXT,
    api_endpoint TEXT,
    logo_url TEXT,
    rating DECIMAL(2,1) DEFAULT 0.0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Vendor pricing table
CREATE TABLE IF NOT EXISTS vendor_pricing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vendor_id UUID REFERENCES vendors(id) ON DELETE CASCADE,
    part_id VARCHAR(100) NOT NULL,
    vendor_part_number VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    shipping_cost DECIMAL(10,2) DEFAULT 0,
    stock_quantity INTEGER DEFAULT 0,
    availability_status VARCHAR(50) DEFAULT 'Unknown',
    delivery_days INTEGER DEFAULT 7,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(vendor_id, part_id)
);

-- Price history for tracking changes
CREATE TABLE IF NOT EXISTS price_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    part_id VARCHAR(100) NOT NULL,
    vendor_id UUID REFERENCES vendors(id) ON DELETE CASCADE,
    price DECIMAL(10,2) NOT NULL,
    shipping_cost DECIMAL(10,2) DEFAULT 0,
    stock_status VARCHAR(50),
    date_recorded DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(part_id, vendor_id, date_recorded)
);

-- Insert default vendors
INSERT INTO vendors (name, display_name, website_url, rating) VALUES
('autozone', 'AutoZone', 'https://www.autozone.com', 4.2),
('rockauto', 'RockAuto', 'https://www.rockauto.com', 4.5),
('summit_racing', 'Summit Racing', 'https://www.summitracing.com', 4.4),
('oreilly_auto', 'O''Reilly Auto Parts', 'https://www.oreillyauto.com', 4.1),
('jegs', 'JEGS', 'https://www.jegs.com', 4.3)
ON CONFLICT (name) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_vendor_pricing_part_id ON vendor_pricing(part_id);
CREATE INDEX IF NOT EXISTS idx_vendor_pricing_vendor_id ON vendor_pricing(vendor_id);
CREATE INDEX IF NOT EXISTS idx_price_history_part_vendor ON price_history(part_id, vendor_id);
CREATE INDEX IF NOT EXISTS idx_price_history_date ON price_history(date_recorded);

-- Update timestamp function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add triggers for updated_at
CREATE TRIGGER update_vendors_updated_at BEFORE UPDATE ON vendors
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    
CREATE TRIGGER update_vendor_pricing_updated_at BEFORE UPDATE ON vendor_pricing
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();