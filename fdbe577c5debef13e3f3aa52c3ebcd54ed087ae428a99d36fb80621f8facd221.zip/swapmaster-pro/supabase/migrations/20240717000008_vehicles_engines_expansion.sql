-- Modern Vehicles and Engines Database Expansion
-- Add hundreds of modern performance vehicles and engines (1990-2025)

-- Create vehicles table if not exists
CREATE TABLE IF NOT EXISTS vehicles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    make VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    generation VARCHAR(50),
    body_style VARCHAR(50),
    start_year INTEGER,
    end_year INTEGER,
    original_engine VARCHAR(100),
    displacement DECIMAL(3,1),
    drivetrain VARCHAR(10), -- 'RWD', 'FWD', 'AWD'
    weight_lbs INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create engines table if not exists
CREATE TABLE IF NOT EXISTS engines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    make VARCHAR(50) NOT NULL,
    code VARCHAR(20),
    family VARCHAR(50),
    displacement DECIMAL(3,1),
    configuration VARCHAR(50), -- 'V8', 'I6', 'V6', 'Twin Turbo V8', etc.
    horsepower INTEGER,
    torque INTEGER,
    compression_ratio DECIMAL(3,1),
    fuel_type VARCHAR(20) DEFAULT 'Gasoline',
    forced_induction VARCHAR(20), -- 'None', 'Turbo', 'Supercharged', 'Twin Turbo'
    difficulty VARCHAR(20) DEFAULT 'Advanced', -- 'Easy', 'Intermediate', 'Advanced', 'Expert'
    popularity INTEGER DEFAULT 50, -- 1-100 popularity score
    production_start INTEGER,
    production_end INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_vehicles_make_model ON vehicles(make, model);
CREATE INDEX IF NOT EXISTS idx_vehicles_year_range ON vehicles(start_year, end_year);
CREATE INDEX IF NOT EXISTS idx_engines_name ON engines(name);
CREATE INDEX IF NOT EXISTS idx_engines_make_family ON engines(make, family);
CREATE INDEX IF NOT EXISTS idx_engines_code ON engines(code);

-- Insert Modern BMW Vehicles (1990-2025)
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('BMW', 'M3', 'E36', 'Coupe', 1992, 1999, '3.0L I6', 3.0, 'RWD', 3219),
('BMW', 'M3', 'E46', 'Coupe', 1999, 2006, '3.2L I6', 3.2, 'RWD', 3415),
('BMW', 'M3', 'E92', 'Coupe', 2007, 2013, '4.0L V8', 4.0, 'RWD', 3704),
('BMW', 'M3', 'F80', 'Sedan', 2014, 2020, '3.0L Twin Turbo I6', 3.0, 'RWD', 3530),
('BMW', 'M3', 'G80', 'Sedan', 2021, 2025, '3.0L Twin Turbo I6', 3.0, 'RWD', 3830),
('BMW', 'M5', 'E34', 'Sedan', 1991, 1995, '3.8L I6', 3.8, 'RWD', 3747),
('BMW', 'M5', 'E39', 'Sedan', 1998, 2003, '4.9L V8', 4.9, 'RWD', 4024),
('BMW', 'M5', 'E60', 'Sedan', 2005, 2010, '5.0L V10', 5.0, 'RWD', 4012),
('BMW', 'M5', 'F10', 'Sedan', 2011, 2016, '4.4L Twin Turbo V8', 4.4, 'RWD', 4387),
('BMW', 'M5', 'F90', 'Sedan', 2017, 2025, '4.4L Twin Turbo V8', 4.4, 'AWD', 4370),
('BMW', 'M2', 'F87', 'Coupe', 2016, 2021, '3.0L Twin Turbo I6', 3.0, 'RWD', 3450),
('BMW', 'M2', 'G87', 'Coupe', 2022, 2025, '3.0L Twin Turbo I6', 3.0, 'RWD', 3814),
('BMW', '335i', 'E90', 'Sedan', 2006, 2013, '3.0L Twin Turbo I6', 3.0, 'RWD', 3582),
('BMW', '340i', 'F30', 'Sedan', 2015, 2019, '3.0L Turbo I6', 3.0, 'RWD', 3582),
('BMW', 'X5M', 'F85', 'SUV', 2015, 2018, '4.4L Twin Turbo V8', 4.4, 'AWD', 5445),
('BMW', 'X6M', 'F86', 'SUV', 2015, 2019, '4.4L Twin Turbo V8', 4.4, 'AWD', 5467);

-- Insert Modern Mercedes-Benz Vehicles (1990-2025)
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Mercedes-AMG', 'C63', 'W204', 'Sedan', 2007, 2014, '6.2L V8', 6.2, 'RWD', 3825),
('Mercedes-AMG', 'C63', 'W205', 'Sedan', 2015, 2021, '4.0L Twin Turbo V8', 4.0, 'RWD', 3814),
('Mercedes-AMG', 'C63', 'W206', 'Sedan', 2022, 2025, '4.0L Twin Turbo V8', 4.0, 'RWD', 4189),
('Mercedes-AMG', 'E63', 'W212', 'Sedan', 2009, 2016, '6.2L V8', 6.2, 'RWD', 4134),
('Mercedes-AMG', 'E63', 'W213', 'Sedan', 2017, 2025, '4.0L Twin Turbo V8', 4.0, 'AWD', 4464),
('Mercedes-AMG', 'S63', 'W222', 'Sedan', 2013, 2020, '5.5L Twin Turbo V8', 5.5, 'RWD', 4850),
('Mercedes-AMG', 'S63', 'W223', 'Sedan', 2021, 2025, '4.0L Twin Turbo V8', 4.0, 'AWD', 5027),
('Mercedes-AMG', 'CLS63', 'W218', 'Coupe', 2011, 2018, '5.5L Twin Turbo V8', 5.5, 'RWD', 4387),
('Mercedes-AMG', 'GLA45', 'H247', 'SUV', 2020, 2025, '2.0L Turbo I4', 2.0, 'AWD', 3902),
('Mercedes-AMG', 'A45', 'W177', 'Hatchback', 2019, 2025, '2.0L Turbo I4', 2.0, 'AWD', 3417);

-- Insert Modern Audi Vehicles (1990-2025)
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Audi', 'RS3', '8P', 'Hatchback', 2011, 2012, '2.5L Turbo I5', 2.5, 'AWD', 3373),
('Audi', 'RS3', '8V', 'Sedan', 2017, 2020, '2.5L Turbo I5', 2.5, 'AWD', 3616),
('Audi', 'RS3', '8Y', 'Sedan', 2021, 2025, '2.5L Turbo I5', 2.5, 'AWD', 3902),
('Audi', 'RS4', 'B7', 'Avant', 2005, 2008, '4.2L V8', 4.2, 'AWD', 3968),
('Audi', 'RS4', 'B9', 'Avant', 2017, 2025, '2.9L Twin Turbo V6', 2.9, 'AWD', 4178),
('Audi', 'RS5', 'B8', 'Coupe', 2010, 2015, '4.2L V8', 4.2, 'AWD', 4013),
('Audi', 'RS5', 'B9', 'Coupe', 2017, 2025, '2.9L Twin Turbo V6', 2.9, 'AWD', 4045),
('Audi', 'RS6', 'C5', 'Avant', 2002, 2004, '4.2L Twin Turbo V8', 4.2, 'AWD', 4189),
('Audi', 'RS6', 'C6', 'Avant', 2008, 2010, '5.0L Twin Turbo V10', 5.0, 'AWD', 4387),
('Audi', 'RS6', 'C7', 'Avant', 2013, 2018, '4.0L Twin Turbo V8', 4.0, 'AWD', 4464),
('Audi', 'RS6', 'C8', 'Avant', 2019, 2025, '4.0L Twin Turbo V8', 4.0, 'AWD', 4795),
('Audi', 'RS7', 'C7', 'Sportback', 2013, 2018, '4.0L Twin Turbo V8', 4.0, 'AWD', 4464),
('Audi', 'RS7', 'C8', 'Sportback', 2019, 2025, '4.0L Twin Turbo V8', 4.0, 'AWD', 4795),
('Audi', 'S4', 'B8', 'Sedan', 2009, 2016, '3.0L Supercharged V6', 3.0, 'AWD', 3814),
('Audi', 'S4', 'B9', 'Sedan', 2017, 2025, '3.0L Turbo V6', 3.0, 'AWD', 3902),
('Audi', 'S6', 'C7', 'Sedan', 2012, 2018, '4.0L Twin Turbo V8', 4.0, 'AWD', 4387),
('Audi', 'R8', 'Type 42', 'Coupe', 2006, 2015, '4.2L V8', 4.2, 'AWD', 3516),
('Audi', 'R8', 'Type 4S', 'Coupe', 2015, 2025, '5.2L V10', 5.2, 'AWD', 3594);

-- Insert Modern Porsche Vehicles (1990-2025)
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Porsche', '911', '993', 'Coupe', 1994, 1998, '3.6L H6', 3.6, 'RWD', 2970),
('Porsche', '911', '996', 'Coupe', 1997, 2005, '3.4L H6', 3.4, 'RWD', 2910),
('Porsche', '911', '997', 'Coupe', 2004, 2012, '3.6L H6', 3.6, 'RWD', 3075),
('Porsche', '911', '991', 'Coupe', 2011, 2019, '3.4L H6', 3.4, 'RWD', 3042),
('Porsche', '911', '992', 'Coupe', 2019, 2025, '3.0L Twin Turbo H6', 3.0, 'RWD', 3354),
('Porsche', '911 Turbo', '993', 'Coupe', 1995, 1998, '3.6L Twin Turbo H6', 3.6, 'AWD', 3307),
('Porsche', '911 Turbo', '996', 'Coupe', 2000, 2005, '3.6L Twin Turbo H6', 3.6, 'AWD', 3395),
('Porsche', '911 Turbo', '997', 'Coupe', 2006, 2013, '3.6L Twin Turbo H6', 3.6, 'AWD', 3494),
('Porsche', '911 Turbo', '991', 'Coupe', 2013, 2020, '3.8L Twin Turbo H6', 3.8, 'AWD', 3516),
('Porsche', '911 Turbo', '992', 'Coupe', 2020, 2025, '3.8L Twin Turbo H6', 3.8, 'AWD', 3640),
('Porsche', 'Cayman', '987', 'Coupe', 2005, 2012, '2.7L H6', 2.7, 'RWD', 2888),
('Porsche', 'Cayman', '981', 'Coupe', 2012, 2016, '2.7L H6', 2.7, 'RWD', 2888),
('Porsche', 'Cayman', '718', 'Coupe', 2016, 2025, '2.0L Turbo H4', 2.0, 'RWD', 3031),
('Porsche', 'Boxster', '986', 'Convertible', 1996, 2004, '2.5L H6', 2.5, 'RWD', 2756),
('Porsche', 'Boxster', '987', 'Convertible', 2004, 2012, '2.7L H6', 2.7, 'RWD', 2976),
('Porsche', 'Boxster', '981', 'Convertible', 2012, 2016, '2.7L H6', 2.7, 'RWD', 2976),
('Porsche', 'Cayenne', '955', 'SUV', 2002, 2010, '4.5L V8', 4.5, 'AWD', 4806),
('Porsche', 'Cayenne', '958', 'SUV', 2010, 2018, '3.6L V6', 3.6, 'AWD', 4365),
('Porsche', 'Cayenne', '9YA', 'SUV', 2018, 2025, '3.0L Turbo V6', 3.0, 'AWD', 4795);

-- Insert Modern American Performance Cars (1990-2025)
-- Ford Mustang
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Ford', 'Mustang GT', 'SN-95', 'Coupe', 1994, 2004, '4.6L V8', 4.6, 'RWD', 3450),
('Ford', 'Mustang GT', 'S197', 'Coupe', 2005, 2014, '4.6L V8', 4.6, 'RWD', 3483),
('Ford', 'Mustang GT', 'S550', 'Coupe', 2015, 2025, '5.0L Coyote V8', 5.0, 'RWD', 3705),
('Ford', 'Mustang Shelby GT350', 'S550', 'Coupe', 2015, 2020, '5.2L Flat-Plane V8', 5.2, 'RWD', 3760),
('Ford', 'Mustang Shelby GT500', 'S550', 'Coupe', 2020, 2025, '5.2L Supercharged V8', 5.2, 'RWD', 4171),
('Ford', 'F-150', 'Twelfth Gen', 'Truck', 2009, 2014, '5.4L V8', 5.4, 'RWD', 4685),
('Ford', 'F-150', 'Thirteenth Gen', 'Truck', 2015, 2020, '3.5L EcoBoost V6', 3.5, 'RWD', 4069),
('Ford', 'F-150', 'Fourteenth Gen', 'Truck', 2021, 2025, '3.5L EcoBoost V6', 3.5, 'RWD', 4069),
('Ford', 'F-150 Raptor', 'SVT', 'Truck', 2010, 2014, '6.2L V8', 6.2, 'AWD', 5665),
('Ford', 'F-150 Raptor', 'Second Gen', 'Truck', 2017, 2025, '3.5L EcoBoost V6', 3.5, 'AWD', 5697);

-- Chevrolet
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Chevrolet', 'Camaro SS', 'Fourth Gen', 'Coupe', 1993, 2002, '5.7L LT1 V8', 5.7, 'RWD', 3439),
('Chevrolet', 'Camaro SS', 'Fifth Gen', 'Coupe', 2010, 2015, '6.2L LS3 V8', 6.2, 'RWD', 3860),
('Chevrolet', 'Camaro SS', 'Sixth Gen', 'Coupe', 2016, 2025, '6.2L LT1 V8', 6.2, 'RWD', 3685),
('Chevrolet', 'Camaro Z28', 'Fifth Gen', 'Coupe', 2014, 2015, '7.0L LS7 V8', 7.0, 'RWD', 3820),
('Chevrolet', 'Camaro ZL1', 'Fifth Gen', 'Coupe', 2012, 2015, '6.2L LSA V8', 6.2, 'RWD', 4120),
('Chevrolet', 'Camaro ZL1', 'Sixth Gen', 'Coupe', 2017, 2025, '6.2L LT4 V8', 6.2, 'RWD', 3883),
('Chevrolet', 'Corvette', 'C4', 'Coupe', 1990, 1996, '5.7L LT1 V8', 5.7, 'RWD', 3245),
('Chevrolet', 'Corvette', 'C5', 'Coupe', 1997, 2004, '5.7L LS1 V8', 5.7, 'RWD', 3245),
('Chevrolet', 'Corvette', 'C6', 'Coupe', 2005, 2013, '6.2L LS3 V8', 6.2, 'RWD', 3179),
('Chevrolet', 'Corvette', 'C7', 'Coupe', 2014, 2019, '6.2L LT1 V8', 6.2, 'RWD', 3298),
('Chevrolet', 'Corvette', 'C8', 'Coupe', 2020, 2025, '6.2L LT2 V8', 6.2, 'RWD', 3366),
('Chevrolet', 'Corvette Z06', 'C6', 'Coupe', 2006, 2013, '7.0L LS7 V8', 7.0, 'RWD', 3132),
('Chevrolet', 'Corvette Z06', 'C7', 'Coupe', 2015, 2019, '6.2L LT4 V8', 6.2, 'RWD', 3524),
('Chevrolet', 'Corvette Z06', 'C8', 'Coupe', 2023, 2025, '5.5L LT6 V8', 5.5, 'RWD', 3434),
('Chevrolet', 'Silverado 1500', 'GMT900', 'Truck', 2007, 2013, '5.3L L83 V8', 5.3, 'RWD', 4718),
('Chevrolet', 'Silverado 1500', 'GMT K2XX', 'Truck', 2014, 2018, '5.3L L83 V8', 5.3, 'RWD', 4387),
('Chevrolet', 'Silverado 1500', 'GMT T1XX', 'Truck', 2019, 2025, '5.3L L84 V8', 5.3, 'RWD', 4474);

-- Dodge
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Dodge', 'Challenger', 'Third Gen', 'Coupe', 2008, 2025, '3.6L V6', 3.6, 'RWD', 3834),
('Dodge', 'Challenger R/T', 'Third Gen', 'Coupe', 2009, 2025, '5.7L HEMI V8', 5.7, 'RWD', 4082),
('Dodge', 'Challenger SRT8', 'Third Gen', 'Coupe', 2008, 2014, '6.1L HEMI V8', 6.1, 'RWD', 4140),
('Dodge', 'Challenger SRT 392', 'Third Gen', 'Coupe', 2015, 2025, '6.4L HEMI V8', 6.4, 'RWD', 4239),
('Dodge', 'Challenger SRT Hellcat', 'Third Gen', 'Coupe', 2015, 2025, '6.2L Supercharged V8', 6.2, 'RWD', 4439),
('Dodge', 'Challenger SRT Demon', 'Third Gen', 'Coupe', 2018, 2018, '6.2L Supercharged V8', 6.2, 'RWD', 4280),
('Dodge', 'Charger', 'Seventh Gen', 'Sedan', 2006, 2025, '3.6L V6', 3.6, 'RWD', 4058),
('Dodge', 'Charger R/T', 'Seventh Gen', 'Sedan', 2006, 2025, '5.7L HEMI V8', 5.7, 'RWD', 4160),
('Dodge', 'Charger SRT8', 'Seventh Gen', 'Sedan', 2006, 2014, '6.1L HEMI V8', 6.1, 'RWD', 4160),
('Dodge', 'Charger SRT 392', 'Seventh Gen', 'Sedan', 2015, 2025, '6.4L HEMI V8', 6.4, 'RWD', 4363),
('Dodge', 'Charger SRT Hellcat', 'Seventh Gen', 'Sedan', 2015, 2025, '6.2L Supercharged V8', 6.2, 'RWD', 4586),
('Dodge', 'Ram 1500', 'Fourth Gen', 'Truck', 2009, 2018, '5.7L HEMI V8', 5.7, 'RWD', 4685),
('Dodge', 'Ram 1500', 'Fifth Gen', 'Truck', 2019, 2025, '5.7L HEMI V8', 5.7, 'RWD', 4798);

-- Japanese Performance Cars
-- Subaru
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Subaru', 'WRX STI', 'GC8', 'Sedan', 1994, 2001, '2.0L Turbo H4', 2.0, 'AWD', 2910),
('Subaru', 'WRX STI', 'GD', 'Sedan', 2004, 2007, '2.5L Turbo H4', 2.5, 'AWD', 3263),
('Subaru', 'WRX STI', 'GR/GV', 'Sedan', 2008, 2014, '2.5L Turbo H4', 2.5, 'AWD', 3373),
('Subaru', 'WRX STI', 'VA', 'Sedan', 2015, 2021, '2.5L Turbo H4', 2.5, 'AWD', 3386),
('Subaru', 'WRX STI', 'VB', 'Sedan', 2022, 2025, '2.4L Turbo H4', 2.4, 'AWD', 3428),
('Subaru', 'BRZ', 'ZN6', 'Coupe', 2012, 2020, '2.0L H4', 2.0, 'RWD', 2762),
('Subaru', 'BRZ', 'ZD8', 'Coupe', 2022, 2025, '2.4L H4', 2.4, 'RWD', 2815);

-- Mitsubishi
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Mitsubishi', 'Lancer Evolution', 'IV', 'Sedan', 1996, 1998, '2.0L Turbo I4', 2.0, 'AWD', 2910),
('Mitsubishi', 'Lancer Evolution', 'V', 'Sedan', 1998, 1999, '2.0L Turbo I4', 2.0, 'AWD', 2910),
('Mitsubishi', 'Lancer Evolution', 'VI', 'Sedan', 1999, 2001, '2.0L Turbo I4', 2.0, 'AWD', 2932),
('Mitsubishi', 'Lancer Evolution', 'VII', 'Sedan', 2001, 2003, '2.0L Turbo I4', 2.0, 'AWD', 2932),
('Mitsubishi', 'Lancer Evolution', 'VIII', 'Sedan', 2003, 2005, '2.0L Turbo I4', 2.0, 'AWD', 3042),
('Mitsubishi', 'Lancer Evolution', 'IX', 'Sedan', 2005, 2007, '2.0L Turbo I4', 2.0, 'AWD', 3175),
('Mitsubishi', 'Lancer Evolution', 'X', 'Sedan', 2007, 2016, '2.0L Turbo I4', 2.0, 'AWD', 3516);

-- Nissan
INSERT INTO vehicles (make, model, generation, body_style, start_year, end_year, original_engine, displacement, drivetrain, weight_lbs) VALUES
('Nissan', 'GT-R', 'R32', 'Coupe', 1989, 1994, '2.6L Twin Turbo I6', 2.6, 'AWD', 3153),
('Nissan', 'GT-R', 'R33', 'Coupe', 1995, 1998, '2.6L Twin Turbo I6', 2.6, 'AWD', 3439),
('Nissan', 'GT-R', 'R34', 'Coupe', 1999, 2002, '2.6L Twin Turbo I6', 2.6, 'AWD', 3439),
('Nissan', 'GT-R', 'R35', 'Coupe', 2007, 2025, '3.8L Twin Turbo V6', 3.8, 'AWD', 3829),
('Nissan', '370Z', 'Z34', 'Coupe', 2009, 2020, '3.7L V6', 3.7, 'RWD', 3278),
('Nissan', 'Z', 'RZ34', 'Coupe', 2022, 2025, '3.0L Twin Turbo V6', 3.0, 'RWD', 3582);

-- Insert Modern Engines with detailed specifications
-- BMW Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('S58', 'BMW', 'S58B30', 'S58', 3.0, 'Twin Turbo I6', 473, 406, 9.3, 'Twin Turbo', 'Expert', 95, 2019, 2025),
('B58', 'BMW', 'B58B30', 'B58', 3.0, 'Turbo I6', 335, 369, 11.0, 'Turbo', 'Advanced', 90, 2015, 2025),
('N54', 'BMW', 'N54B30', 'N54', 3.0, 'Twin Turbo I6', 300, 300, 10.2, 'Twin Turbo', 'Advanced', 85, 2006, 2016),
('N55', 'BMW', 'N55B30', 'N55', 3.0, 'Turbo I6', 300, 300, 10.2, 'Turbo', 'Intermediate', 80, 2009, 2017),
('S65', 'BMW', 'S65B40', 'S65', 4.0, 'V8', 414, 295, 12.0, 'None', 'Expert', 75, 2007, 2013),
('S63', 'BMW', 'S63B44', 'S63', 4.4, 'Twin Turbo V8', 560, 502, 10.0, 'Twin Turbo', 'Expert', 85, 2010, 2025);

-- Mercedes-AMG Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('M177', 'Mercedes-AMG', 'M177', 'AMG V8', 4.0, 'Twin Turbo V8', 469, 479, 10.5, 'Twin Turbo', 'Expert', 90, 2015, 2025),
('M178', 'Mercedes-AMG', 'M178', 'AMG V8', 4.0, 'Twin Turbo V8', 503, 443, 9.0, 'Twin Turbo', 'Expert', 85, 2015, 2025),
('M159', 'Mercedes-AMG', 'M159', 'AMG V8', 6.2, 'V8', 451, 443, 11.3, 'None', 'Advanced', 75, 2006, 2015),
('M156', 'Mercedes-AMG', 'M156', 'AMG V8', 6.2, 'V8', 518, 465, 11.3, 'None', 'Advanced', 70, 2007, 2014),
('M133', 'Mercedes-AMG', 'M133', 'AMG I4', 2.0, 'Turbo I4', 416, 369, 9.0, 'Turbo', 'Advanced', 80, 2019, 2025);

-- Ford Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('Coyote 5.0', 'Ford', '5.0L Ti-VCT', 'Coyote', 5.0, 'V8', 460, 420, 11.0, 'None', 'Intermediate', 95, 2011, 2025),
('Voodoo 5.2', 'Ford', '5.2L', 'Voodoo', 5.2, 'Flat-Plane V8', 526, 429, 12.0, 'None', 'Expert', 80, 2015, 2020),
('Predator 5.2', 'Ford', '5.2L SC', 'Predator', 5.2, 'Supercharged V8', 760, 625, 9.5, 'Supercharged', 'Expert', 90, 2020, 2025),
('EcoBoost 3.5', 'Ford', '3.5L EcoBoost', 'EcoBoost', 3.5, 'Twin Turbo V6', 450, 510, 10.0, 'Twin Turbo', 'Advanced', 85, 2009, 2025),
('EcoBoost 2.3', 'Ford', '2.3L EcoBoost', 'EcoBoost', 2.3, 'Turbo I4', 310, 350, 9.5, 'Turbo', 'Intermediate', 75, 2015, 2025);

-- GM/Chevrolet Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('LS1', 'Chevrolet', 'LS1', 'LS', 5.7, 'V8', 350, 365, 10.1, 'None', 'Intermediate', 95, 1997, 2004),
('LS2', 'Chevrolet', 'LS2', 'LS', 6.0, 'V8', 400, 400, 10.9, 'None', 'Intermediate', 85, 2005, 2009),
('LS3', 'Chevrolet', 'LS3', 'LS', 6.2, 'V8', 430, 424, 10.7, 'None', 'Intermediate', 90, 2008, 2017),
('LS7', 'Chevrolet', 'LS7', 'LS', 7.0, 'V8', 505, 470, 11.0, 'None', 'Advanced', 85, 2005, 2015),
('LS9', 'Chevrolet', 'LS9', 'LS', 6.2, 'Supercharged V8', 638, 604, 9.1, 'Supercharged', 'Expert', 80, 2009, 2013),
('LT1', 'Chevrolet', 'LT1', 'LT', 6.2, 'V8', 460, 465, 11.5, 'None', 'Intermediate', 90, 2014, 2025),
('LT4', 'Chevrolet', 'LT4', 'LT', 6.2, 'Supercharged V8', 650, 650, 10.0, 'Supercharged', 'Expert', 85, 2015, 2025),
('LT5', 'Chevrolet', 'LT5', 'LT', 6.2, 'Supercharged V8', 755, 715, 9.8, 'Supercharged', 'Expert', 75, 2019, 2025),
('LT2', 'Chevrolet', 'LT2', 'LT', 6.2, 'V8', 495, 470, 11.5, 'None', 'Advanced', 85, 2020, 2025),
('LT6', 'Chevrolet', 'LT6', 'LT', 5.5, 'V8', 670, 460, 12.0, 'None', 'Expert', 80, 2023, 2025);

-- Dodge/Chrysler Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('5.7L HEMI', 'Dodge', '5.7L HEMI', 'HEMI', 5.7, 'V8', 375, 410, 10.5, 'None', 'Intermediate', 90, 2003, 2025),
('6.1L HEMI', 'Dodge', '6.1L SRT', 'HEMI', 6.1, 'V8', 425, 420, 10.3, 'None', 'Advanced', 75, 2005, 2010),
('6.4L HEMI', 'Dodge', '6.4L SRT', 'HEMI', 6.4, 'V8', 485, 475, 10.9, 'None', 'Advanced', 85, 2011, 2025),
('6.2L Hellcat', 'Dodge', '6.2L SC', 'Hellcat', 6.2, 'Supercharged V8', 717, 656, 9.5, 'Supercharged', 'Expert', 95, 2015, 2025),
('6.2L Demon', 'Dodge', '6.2L SC', 'Hellcat', 6.2, 'Supercharged V8', 840, 770, 9.5, 'Supercharged', 'Expert', 70, 2018, 2018);

-- Audi Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('2.5T I5', 'Audi', 'CEPA', 'EA855', 2.5, 'Turbo I5', 394, 354, 9.6, 'Turbo', 'Advanced', 85, 2009, 2025),
('4.0T V8', 'Audi', 'CGKA', 'EA825', 4.0, 'Twin Turbo V8', 591, 590, 10.0, 'Twin Turbo', 'Expert', 80, 2012, 2025),
('3.0T V6', 'Audi', 'CGXB', 'EA839', 3.0, 'Turbo V6', 349, 369, 10.3, 'Turbo', 'Advanced', 75, 2017, 2025),
('3.0 SC V6', 'Audi', 'CAKA', 'EA837', 3.0, 'Supercharged V6', 333, 325, 10.3, 'Supercharged', 'Advanced', 70, 2009, 2018);

-- Porsche Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('3.8L Twin Turbo H6', 'Porsche', '9A1', '911 Turbo', 3.8, 'Twin Turbo H6', 572, 553, 9.8, 'Twin Turbo', 'Expert', 80, 2013, 2025),
('4.0L H6', 'Porsche', '9A2', '911 GT3', 4.0, 'H6', 502, 346, 12.9, 'None', 'Expert', 75, 2016, 2025),
('3.0L Twin Turbo H6', 'Porsche', '9A1', '911 Carrera', 3.0, 'Twin Turbo H6', 379, 331, 10.0, 'Twin Turbo', 'Advanced', 85, 2016, 2025);

-- Japanese Engines
INSERT INTO engines (name, make, code, family, displacement, configuration, horsepower, torque, compression_ratio, forced_induction, difficulty, popularity, production_start, production_end) VALUES
('EJ257', 'Subaru', 'EJ257', 'EJ', 2.5, 'Turbo H4', 305, 290, 8.2, 'Turbo', 'Advanced', 80, 2004, 2019),
('FA24', 'Subaru', 'FA24F', 'FA', 2.4, 'Turbo H4', 271, 258, 10.6, 'Turbo', 'Advanced', 75, 2022, 2025),
('4G63T', 'Mitsubishi', '4G63T', '4G63', 2.0, 'Turbo I4', 276, 289, 8.8, 'Turbo', 'Advanced', 85, 1988, 2007),
('RB26DETT', 'Nissan', 'RB26DETT', 'RB', 2.6, 'Twin Turbo I6', 276, 293, 8.5, 'Twin Turbo', 'Expert', 95, 1989, 2002),
('VR38DETT', 'Nissan', 'VR38DETT', 'VR', 3.8, 'Twin Turbo V6', 565, 467, 9.0, 'Twin Turbo', 'Expert', 85, 2007, 2025);

-- Create RLS policies for new tables
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE engines ENABLE ROW LEVEL SECURITY;

-- Public read access for vehicles and engines
CREATE POLICY "Vehicles are publicly readable" ON vehicles FOR SELECT USING (true);
CREATE POLICY "Engines are publicly readable" ON engines FOR SELECT USING (true);

-- Only authenticated users can insert/update (for admin functions)
CREATE POLICY "Authenticated users can manage vehicles" ON vehicles FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Authenticated users can manage engines" ON engines FOR ALL USING (auth.role() = 'authenticated');
