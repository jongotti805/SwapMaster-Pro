-- Fix the increment syntax in review helpful function

-- Create a function to safely increment helpful count
CREATE OR REPLACE FUNCTION increment_review_helpful_count(review_id_param UUID)
RETURNS VOID AS $$
BEGIN
    UPDATE swap_reviews 
    SET helpful_count = helpful_count + 1
    WHERE id = review_id_param;
END;
$$ LANGUAGE plpgsql;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION increment_review_helpful_count(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION increment_review_helpful_count(UUID) TO service_role;