Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const requestData = await req.json();
        const { action, threadId, commentId, content, title, tags, images, reviewId } = requestData;
        
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        
        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header (optional for some read operations)
        let userId = null;
        const authHeader = req.headers.get('authorization');
        if (authHeader) {
            try {
                const token = authHeader.replace('Bearer ', '');
                const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'apikey': serviceRoleKey
                    }
                });

                if (userResponse.ok) {
                    const userData = await userResponse.json();
                    userId = userData.id;
                }
            } catch (error) {
                console.log('Could not get user from token:', error.message);
            }
        }

        switch (action) {
            case 'create_thread':
                if (!userId) throw new Error('Authentication required');
                return await createBuildThread(supabaseUrl, serviceRoleKey, userId, { title, content, tags, images }, corsHeaders);
            
            case 'get_threads':
                return await getBuildThreads(supabaseUrl, serviceRoleKey, corsHeaders);
            
            case 'get_thread':
                return await getBuildThread(supabaseUrl, serviceRoleKey, threadId, corsHeaders);
            
            case 'add_comment':
                if (!userId) throw new Error('Authentication required');
                return await addComment(supabaseUrl, serviceRoleKey, userId, threadId, content, corsHeaders);
            
            case 'like_thread':
                if (!userId) throw new Error('Authentication required');
                return await likeThread(supabaseUrl, serviceRoleKey, userId, threadId, corsHeaders);
            
            case 'like_comment':
                if (!userId) throw new Error('Authentication required');
                return await likeComment(supabaseUrl, serviceRoleKey, userId, commentId, corsHeaders);
            
            case 'follow_thread':
                if (!userId) throw new Error('Authentication required');
                return await followThread(supabaseUrl, serviceRoleKey, userId, threadId, corsHeaders);
            
            case 'create_swap_review':
                if (!userId) throw new Error('Authentication required');
                return await createSwapReview(supabaseUrl, serviceRoleKey, userId, requestData, corsHeaders);
            
            case 'get_swap_reviews':
                return await getSwapReviews(supabaseUrl, serviceRoleKey, requestData, corsHeaders);
            
            case 'mark_review_helpful':
                if (!userId) throw new Error('Authentication required');
                return await markReviewHelpful(supabaseUrl, serviceRoleKey, userId, reviewId, corsHeaders);
            
            default:
                throw new Error('Invalid action');
        }

    } catch (error) {
        console.error('Community features error:', error);
        
        const errorResponse = {
            error: {
                code: 'COMMUNITY_FEATURES_FAILED',
                message: error.message
            }
        };
        
        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// Create a new build thread
async function createBuildThread(supabaseUrl, serviceRoleKey, userId, threadData, corsHeaders) {
    try {
        const { title, content, tags, images } = threadData;
        
        if (!title || !content) {
            throw new Error('Title and content are required');
        }
        
        // Create the thread
        const threadResponse = await fetch(`${supabaseUrl}/rest/v1/build_threads`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                user_id: userId,
                title: title,
                content: {
                    text: content,
                    images: images || []
                },
                tags: tags || [],
                is_public: true,
                created_at: new Date().toISOString()
            })
        });
        
        if (!threadResponse.ok) {
            const errorText = await threadResponse.text();
            throw new Error(`Failed to create thread: ${errorText}`);
        }
        
        const newThread = await threadResponse.json();
        
        // Award credits for creating a build thread
        try {
            await fetch(`${supabaseUrl}/functions/v1/credit-economy`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'earn_credits',
                    userId: userId,
                    opportunityId: 'build_thread_post'
                })
            });
        } catch (creditError) {
            console.warn('Failed to award credits:', creditError);
        }
        
        return new Response(JSON.stringify({
            data: newThread[0]
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to create build thread: ${error.message}`);
    }
}

// Get all build threads with pagination
async function getBuildThreads(supabaseUrl, serviceRoleKey, corsHeaders) {
    try {
        const threadsResponse = await fetch(`${supabaseUrl}/rest/v1/build_threads?select=*,build_thread_likes(count),build_thread_comments(count)&order=created_at.desc&limit=20`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        if (!threadsResponse.ok) {
            throw new Error('Failed to fetch threads');
        }
        
        const threads = await threadsResponse.json();
        
        return new Response(JSON.stringify({
            data: threads.map(thread => ({
                id: thread.id,
                title: thread.title,
                content: thread.content,
                tags: thread.tags,
                userId: thread.user_id,
                createdAt: thread.created_at,
                updatedAt: thread.updated_at,
                likesCount: thread.build_thread_likes?.[0]?.count || 0,
                commentsCount: thread.build_thread_comments?.[0]?.count || 0,
                isPublic: thread.is_public
            }))
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to get build threads: ${error.message}`);
    }
}

// Get a specific build thread with comments
async function getBuildThread(supabaseUrl, serviceRoleKey, threadId, corsHeaders) {
    try {
        if (!threadId) {
            throw new Error('Thread ID is required');
        }
        
        // Get thread details
        const threadResponse = await fetch(`${supabaseUrl}/rest/v1/build_threads?id=eq.${threadId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const threads = await threadResponse.json();
        if (threads.length === 0) {
            throw new Error('Thread not found');
        }
        
        const thread = threads[0];
        
        // Get comments for this thread
        const commentsResponse = await fetch(`${supabaseUrl}/rest/v1/build_thread_comments?thread_id=eq.${threadId}&order=created_at.desc`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const comments = await commentsResponse.json();
        
        // Get likes count
        const likesResponse = await fetch(`${supabaseUrl}/rest/v1/build_thread_likes?thread_id=eq.${threadId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const likes = await likesResponse.json();
        
        return new Response(JSON.stringify({
            data: {
                thread: {
                    id: thread.id,
                    title: thread.title,
                    content: thread.content,
                    tags: thread.tags,
                    userId: thread.user_id,
                    createdAt: thread.created_at,
                    updatedAt: thread.updated_at,
                    likesCount: likes.length,
                    isPublic: thread.is_public
                },
                comments: comments.map(comment => ({
                    id: comment.id,
                    content: comment.content,
                    userId: comment.user_id,
                    createdAt: comment.created_at,
                    likesCount: 0 // TODO: implement comment likes count
                }))
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to get build thread: ${error.message}`);
    }
}

// Add a comment to a build thread
async function addComment(supabaseUrl, serviceRoleKey, userId, threadId, content, corsHeaders) {
    try {
        if (!threadId || !content) {
            throw new Error('Thread ID and content are required');
        }
        
        const commentResponse = await fetch(`${supabaseUrl}/rest/v1/build_thread_comments`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                thread_id: threadId,
                user_id: userId,
                content: content,
                created_at: new Date().toISOString()
            })
        });
        
        if (!commentResponse.ok) {
            throw new Error('Failed to add comment');
        }
        
        const newComment = await commentResponse.json();
        
        // Award credits for helpful comment
        try {
            await fetch(`${supabaseUrl}/functions/v1/credit-economy`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'earn_credits',
                    userId: userId,
                    opportunityId: 'helpful_comment'
                })
            });
        } catch (creditError) {
            console.warn('Failed to award credits for comment:', creditError);
        }
        
        return new Response(JSON.stringify({
            data: newComment[0]
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to add comment: ${error.message}`);
    }
}

// Like/unlike a build thread
async function likeThread(supabaseUrl, serviceRoleKey, userId, threadId, corsHeaders) {
    try {
        if (!threadId) {
            throw new Error('Thread ID is required');
        }
        
        // Check if user already liked this thread
        const existingLike = await fetch(`${supabaseUrl}/rest/v1/build_thread_likes?user_id=eq.${userId}&thread_id=eq.${threadId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const likes = await existingLike.json();
        
        if (likes.length > 0) {
            // Unlike - remove the like
            await fetch(`${supabaseUrl}/rest/v1/build_thread_likes?user_id=eq.${userId}&thread_id=eq.${threadId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            
            return new Response(JSON.stringify({
                data: { liked: false }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        } else {
            // Like - add the like
            await fetch(`${supabaseUrl}/rest/v1/build_thread_likes`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_id: userId,
                    thread_id: threadId,
                    created_at: new Date().toISOString()
                })
            });
            
            return new Response(JSON.stringify({
                data: { liked: true }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        }
        
    } catch (error) {
        throw new Error(`Failed to like thread: ${error.message}`);
    }
}

// Like/unlike a comment
async function likeComment(supabaseUrl, serviceRoleKey, userId, commentId, corsHeaders) {
    try {
        if (!commentId) {
            throw new Error('Comment ID is required');
        }
        
        // Similar logic to likeThread but for comments
        // Implementation would be similar to likeThread
        
        return new Response(JSON.stringify({
            data: { liked: true }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to like comment: ${error.message}`);
    }
}

// Follow/unfollow a build thread
async function followThread(supabaseUrl, serviceRoleKey, userId, threadId, corsHeaders) {
    try {
        if (!threadId) {
            throw new Error('Thread ID is required');
        }
        
        // Check if user is already following
        const existingFollow = await fetch(`${supabaseUrl}/rest/v1/thread_followers?user_id=eq.${userId}&thread_id=eq.${threadId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const follows = await existingFollow.json();
        
        if (follows.length > 0) {
            // Unfollow
            await fetch(`${supabaseUrl}/rest/v1/thread_followers?user_id=eq.${userId}&thread_id=eq.${threadId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            
            return new Response(JSON.stringify({
                data: { following: false }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        } else {
            // Follow
            await fetch(`${supabaseUrl}/rest/v1/thread_followers`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_id: userId,
                    thread_id: threadId,
                    created_at: new Date().toISOString()
                })
            });
            
            return new Response(JSON.stringify({
                data: { following: true }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        }
        
    } catch (error) {
        throw new Error(`Failed to follow thread: ${error.message}`);
    }
}

// Create a new swap review
async function createSwapReview(supabaseUrl, serviceRoleKey, userId, reviewData, corsHeaders) {
    try {
        const {
            title, review_text, rating, difficulty_rating, cost_rating,
            actual_cost, time_taken_hours, would_recommend, pros, cons,
            tags, swap_status, vehicle_year, vehicle_make, vehicle_model,
            engine_name, engine_make
        } = reviewData;
        
        if (!title || !review_text || !rating) {
            throw new Error('Title, review text, and rating are required');
        }
        
        // Get user profile for reviewer name
        const profileResponse = await fetch(`${supabaseUrl}/rest/v1/user_profiles?user_id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        let reviewerName = 'Anonymous User';
        let reviewerAvatar = null;
        
        if (profileResponse.ok) {
            const profiles = await profileResponse.json();
            if (profiles.length > 0) {
                reviewerName = profiles[0].full_name || profiles[0].username || 'Anonymous User';
                reviewerAvatar = profiles[0].avatar_url;
            }
        }
        
        // Create the review
        const reviewResponse = await fetch(`${supabaseUrl}/rest/v1/swap_reviews`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                user_id: userId,
                reviewer_name: reviewerName,
                reviewer_avatar: reviewerAvatar,
                vehicle_year: vehicle_year,
                vehicle_make: vehicle_make,
                vehicle_model: vehicle_model,
                engine_name: engine_name,
                engine_make: engine_make,
                rating: rating,
                difficulty_rating: difficulty_rating || 3,
                cost_rating: cost_rating || 3,
                title: title,
                review_text: review_text,
                pros: pros || [],
                cons: cons || [],
                actual_cost: actual_cost || 0,
                time_taken_hours: time_taken_hours || 0,
                would_recommend: would_recommend !== false,
                images: [],
                helpful_count: 0,
                tags: tags || [],
                swap_status: swap_status || 'completed',
                created_at: new Date().toISOString()
            })
        });
        
        if (!reviewResponse.ok) {
            const errorText = await reviewResponse.text();
            throw new Error(`Failed to create review: ${errorText}`);
        }
        
        const newReview = await reviewResponse.json();
        
        // Award credits for creating a review
        try {
            await fetch(`${supabaseUrl}/functions/v1/credit-economy`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'earn_credits',
                    userId: userId,
                    opportunityId: 'community_review'
                })
            });
        } catch (creditError) {
            console.warn('Failed to award credits:', creditError);
        }
        
        return new Response(JSON.stringify({
            data: newReview[0]
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to create swap review: ${error.message}`);
    }
}

// Get swap reviews with filtering
async function getSwapReviews(supabaseUrl, serviceRoleKey, requestData, corsHeaders) {
    try {
        const {
            vehicleMake, vehicleModel, vehicleYear,
            engineMake, engineName, filterBy, sortBy
        } = requestData;
        
        let query = `${supabaseUrl}/rest/v1/swap_reviews?select=*`;
        
        // Add filters
        const filters = [];
        if (vehicleMake) filters.push(`vehicle_make.ilike.*${vehicleMake}*`);
        if (vehicleModel) filters.push(`vehicle_model.ilike.*${vehicleModel}*`);
        if (vehicleYear) filters.push(`vehicle_year.eq.${vehicleYear}`);
        if (engineMake) filters.push(`engine_make.ilike.*${engineMake}*`);
        if (engineName) filters.push(`engine_name.ilike.*${engineName}*`);
        if (filterBy && filterBy !== 'all') filters.push(`swap_status.eq.${filterBy}`);
        
        if (filters.length > 0) {
            query += '&' + filters.join('&');
        }
        
        // Add sorting
        switch (sortBy) {
            case 'oldest':
                query += '&order=created_at.asc';
                break;
            case 'rating_high':
                query += '&order=rating.desc';
                break;
            case 'rating_low':
                query += '&order=rating.asc';
                break;
            case 'helpful':
                query += '&order=helpful_count.desc';
                break;
            default:
                query += '&order=created_at.desc';
        }
        
        query += '&limit=20';
        
        const reviewsResponse = await fetch(query, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        if (!reviewsResponse.ok) {
            throw new Error('Failed to fetch reviews');
        }
        
        const reviews = await reviewsResponse.json();
        
        return new Response(JSON.stringify({
            data: reviews
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to get swap reviews: ${error.message}`);
    }
}

// Mark a review as helpful
async function markReviewHelpful(supabaseUrl, serviceRoleKey, userId, reviewId, corsHeaders) {
    try {
        if (!reviewId) {
            throw new Error('Review ID is required');
        }
        
        // Check if user already marked this review as helpful
        const existingHelpful = await fetch(`${supabaseUrl}/rest/v1/review_helpful?user_id=eq.${userId}&review_id=eq.${reviewId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const helpfulEntries = await existingHelpful.json();
        
        if (helpfulEntries.length > 0) {
            throw new Error('You have already marked this review as helpful');
        }
        
        // Add helpful entry
        await fetch(`${supabaseUrl}/rest/v1/review_helpful`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                review_id: reviewId,
                created_at: new Date().toISOString()
            })
        });
        
        // Increment helpful count on the review using database function
        await fetch(`${supabaseUrl}/rest/v1/rpc/increment_review_helpful_count`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                review_id_param: reviewId
            })
        });
        
        return new Response(JSON.stringify({
            data: { success: true }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to mark review as helpful: ${error.message}`);
    }
}