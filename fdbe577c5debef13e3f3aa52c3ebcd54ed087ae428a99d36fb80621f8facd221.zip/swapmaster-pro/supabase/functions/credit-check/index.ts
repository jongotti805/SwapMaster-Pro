Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Get environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('No authorization header');
        }

        const token = authHeader.replace('Bearer ', '');

        // Verify token and get user
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        // Get user credits
        const creditsResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            }
        });

        if (!creditsResponse.ok) {
            throw new Error('Failed to fetch user credits');
        }

        const creditsData = await creditsResponse.json();
        const userCredits = creditsData[0];

        // Check for unlimited subscription
        const subscriptionResponse = await fetch(
            `${supabaseUrl}/rest/v1/gearshift_subscriptions?user_id=eq.${userId}&status=eq.active&select=*,gearshift_plans!price_id(plan_type)`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        const subscriptions = subscriptionResponse.ok ? await subscriptionResponse.json() : [];
        const hasUnlimited = subscriptions.some((sub: any) => 
            sub.gearshift_plans?.plan_type === 'unlimited'
        );

        return new Response(JSON.stringify({
            data: {
                creditsRemaining: userCredits?.credits_remaining || 0,
                totalCreditsUsed: userCredits?.total_credits_used || 0,
                totalEarnedCredits: userCredits?.total_earned_credits || 0,
                hasUnlimitedSubscription: hasUnlimited,
                lastCreditUsed: userCredits?.last_credit_used,
                lastCreditPurchase: userCredits?.last_credit_purchase
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Credit check error:', error);

        const errorResponse = {
            error: {
                code: 'CREDIT_CHECK_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});