Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Extract part number from request body
        const requestData = await req.json();
        const { partNumber } = requestData;

        if (!partNumber) {
            throw new Error('Part number is required');
        }

        // Get API keys from environment
        const autoZoneApiKey = Deno.env.get('AUTOZONE_API_KEY');
        
        if (!autoZoneApiKey) {
            throw new Error('AutoZone API key not configured');
        }

        // Fetch pricing from both sources
        const [autoZoneData, rockAutoData] = await Promise.allSettled([
            fetchAutoZonePricing(partNumber, autoZoneApiKey),
            fetchRockAutoPricing(partNumber) // Mock service
        ]);

        // Process results
        const result = {
            partNumber,
            vendors: {
                autozone: autoZoneData.status === 'fulfilled' ? autoZoneData.value : {
                    error: autoZoneData.status === 'rejected' ? autoZoneData.reason.message : 'Unknown error',
                    available: false
                },
                rockauto: rockAutoData.status === 'fulfilled' ? rockAutoData.value : {
                    error: rockAutoData.status === 'rejected' ? rockAutoData.reason.message : 'Unknown error',
                    available: false
                }
            },
            timestamp: new Date().toISOString()
        };

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Vendor pricing error:', error);

        const errorResponse = {
            error: {
                code: 'VENDOR_PRICING_ERROR',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// Real AutoZone API integration
async function fetchAutoZonePricing(partNumber: string, apiKey: string) {
    try {
        // AutoZone API endpoint (this is a common pattern for parts APIs)
        const autoZoneUrl = `https://api.autozone.com/v1/parts/search?partNumber=${encodeURIComponent(partNumber)}`;
        
        const response = await fetch(autoZoneUrl, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`AutoZone API error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        
        // Process AutoZone response format
        if (data.products && data.products.length > 0) {
            const product = data.products[0];
            return {
                vendor: 'AutoZone',
                available: true,
                partNumber: product.partNumber || partNumber,
                name: product.name || product.description,
                price: product.price || product.listPrice,
                salePrice: product.salePrice,
                inStock: product.inStock !== false,
                stockCount: product.stockCount || null,
                brand: product.brand || product.manufacturer,
                category: product.category,
                description: product.description,
                imageUrl: product.imageUrl || product.images?.[0]?.url,
                productUrl: product.productUrl || `https://www.autozone.com/parts/${partNumber}`,
                specifications: product.specifications || {},
                warranty: product.warranty
            };
        } else {
            return {
                vendor: 'AutoZone',
                available: false,
                partNumber,
                message: 'Part not found'
            };
        }
    } catch (error) {
        console.error('AutoZone API error:', error);
        throw new Error(`AutoZone API failed: ${error.message}`);
    }
}

// Mock RockAuto service (realistic fake data)
async function fetchRockAutoPricing(partNumber: string) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 500 + 200));
    
    // Generate realistic mock data based on part number
    const mockBrands = ['ACDelco', 'Bosch', 'Delphi', 'Motorcraft', 'NGK', 'Denso', 'Gates', 'Fram'];
    const mockCategories = ['Engine', 'Brake', 'Suspension', 'Electrical', 'Filter', 'Ignition', 'Cooling'];
    
    // Create deterministic but varied data based on part number
    const hash = partNumber.split('').reduce((a, b) => {
        a = ((a << 5) - a) + b.charCodeAt(0);
        return a & a;
    }, 0);
    
    const brandIndex = Math.abs(hash) % mockBrands.length;
    const categoryIndex = Math.abs(hash >> 4) % mockCategories.length;
    const basePrice = 15 + (Math.abs(hash >> 8) % 200);
    const isAvailable = Math.abs(hash >> 12) % 10 > 1; // 80% availability rate
    
    if (!isAvailable) {
        return {
            vendor: 'RockAuto',
            available: false,
            partNumber,
            message: 'Part temporarily out of stock'
        };
    }
    
    return {
        vendor: 'RockAuto',
        available: true,
        partNumber,
        name: `${mockBrands[brandIndex]} ${mockCategories[categoryIndex]} Part`,
        price: basePrice.toFixed(2),
        salePrice: (basePrice * 0.9).toFixed(2), // 10% discount
        inStock: true,
        stockCount: 5 + (Math.abs(hash >> 16) % 20),
        brand: mockBrands[brandIndex],
        category: mockCategories[categoryIndex],
        description: `High-quality ${mockCategories[categoryIndex].toLowerCase()} component for reliable performance`,
        imageUrl: `https://images.rockauto.com/parts/${partNumber}.jpg`,
        productUrl: `https://www.rockauto.com/en/catalog/${partNumber}`,
        specifications: {
            weight: `${(1 + Math.abs(hash >> 20) % 10).toFixed(1)} lbs`,
            dimensions: `${4 + Math.abs(hash >> 24) % 8}" x ${3 + Math.abs(hash >> 28) % 6}" x ${2 + Math.abs(hash >> 32) % 4}"`,
            material: hash % 2 === 0 ? 'Steel' : 'Aluminum'
        },
        warranty: '12 months'
    };
}