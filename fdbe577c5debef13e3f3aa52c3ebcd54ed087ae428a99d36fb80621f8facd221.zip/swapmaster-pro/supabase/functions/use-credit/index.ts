Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { featureName, creditsRequired } = await req.json();
        const requiredCredits = creditsRequired || 1;

        if (!featureName) {
            throw new Error('Feature name is required');
        }

        // Get environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('No authorization header');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        // Check for unlimited subscription first
        const subscriptionResponse = await fetch(
            `${supabaseUrl}/rest/v1/gearshift_subscriptions?user_id=eq.${userId}&status=eq.active&select=*,gearshift_plans!price_id(plan_type)`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (subscriptionResponse.ok) {
            const subscriptions = await subscriptionResponse.json();
            const hasUnlimited = subscriptions.some((sub: any) => 
                sub.gearshift_plans?.plan_type === 'unlimited'
            );
            
            if (hasUnlimited) {
                // Log usage for unlimited users but don't deduct credits
                await fetch(`${supabaseUrl}/rest/v1/feature_usage_log`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        feature_name: featureName,
                        credits_used: 0
                    })
                });

                return new Response(JSON.stringify({
                    data: {
                        success: true,
                        creditsUsed: 0,
                        hasUnlimited: true
                    }
                }), {
                    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
            }
        }

        // Get current credit balance
        const creditsResponse = await fetch(
            `${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!creditsResponse.ok) {
            throw new Error('Failed to fetch user credits');
        }

        const creditsData = await creditsResponse.json();
        let userCredits = creditsData[0];

        // Create credits record if doesn't exist
        if (!userCredits) {
            const createResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    user_id: userId,
                    credits_remaining: 3,
                    total_earned_credits: 3,
                    total_credits_used: 0
                })
            });
            
            if (createResponse.ok) {
                const newCredits = await createResponse.json();
                userCredits = newCredits[0];
            } else {
                throw new Error('Failed to create user credits record');
            }
        }

        // Check if user has enough credits
        if (userCredits.credits_remaining < requiredCredits) {
            return new Response(JSON.stringify({
                data: {
                    success: false,
                    error: 'INSUFFICIENT_CREDITS',
                    creditsRemaining: userCredits.credits_remaining,
                    creditsRequired: requiredCredits
                }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        }

        // Deduct credits
        const newCreditsRemaining = userCredits.credits_remaining - requiredCredits;
        const newTotalUsed = userCredits.total_credits_used + requiredCredits;

        const updateResponse = await fetch(
            `${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`,
            {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    credits_remaining: newCreditsRemaining,
                    total_credits_used: newTotalUsed,
                    last_credit_used: new Date().toISOString(),
                    updated_at: new Date().toISOString()
                })
            }
        );

        if (!updateResponse.ok) {
            throw new Error('Failed to update credit balance');
        }

        // Log feature usage
        await fetch(`${supabaseUrl}/rest/v1/feature_usage_log`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                feature_name: featureName,
                credits_used: requiredCredits
            })
        });

        return new Response(JSON.stringify({
            data: {
                success: true,
                creditsUsed: requiredCredits,
                creditsRemaining: newCreditsRemaining,
                hasUnlimited: false
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Credit usage error:', error);

        const errorResponse = {
            error: {
                code: 'CREDIT_USAGE_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});