// Supplier Verification System
// Handles supplier applications, verification process, and subscription management

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, ...actionData } = await req.json();

        console.log('Supplier verification action:', action);

        // Get environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('Authorization required');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid authentication token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        let result = null;

        switch (action) {
            case 'submit_application':
                result = await submitSupplierApplication(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'update_application':
                result = await updateSupplierApplication(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'create_stripe_subscription':
                result = await createStripeSubscription(supabaseUrl, serviceRoleKey, stripeSecretKey, userId, actionData);
                break;
            case 'cancel_subscription':
                result = await cancelSubscription(supabaseUrl, serviceRoleKey, stripeSecretKey, userId, actionData);
                break;
            case 'get_verification_status':
                result = await getVerificationStatus(supabaseUrl, serviceRoleKey, userId);
                break;
            case 'submit_product':
                result = await submitProduct(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'update_trust_score':
                result = await updateTrustScore(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Supplier verification error:', error);

        const errorResponse = {
            error: {
                code: 'SUPPLIER_VERIFICATION_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function submitSupplierApplication(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const {
        businessName,
        businessLicense,
        taxId,
        businessAddress,
        phone,
        website,
        businessType,
        specialties,
        serviceAreas,
        businessHours,
        paymentMethods,
        shippingOptions,
        returnPolicy,
        warrantyPolicy,
        documents
    } = data;

    // Validate required fields
    if (!businessName || !phone || !businessAddress) {
        throw new Error('Business name, phone, and address are required');
    }

    const applicationData = {
        user_id: userId,
        application_data: {
            businessName,
            businessLicense,
            taxId,
            businessAddress,
            phone,
            website,
            businessType,
            specialties: specialties || [],
            serviceAreas: serviceAreas || [],
            businessHours: businessHours || {},
            paymentMethods: paymentMethods || [],
            shippingOptions: shippingOptions || [],
            returnPolicy,
            warrantyPolicy
        },
        documents: documents || [],
        status: 'submitted',
        created_at: new Date().toISOString()
    };

    // Submit application
    const response = await fetch(`${supabaseUrl}/rest/v1/supplier_applications`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(applicationData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to submit application: ${errorText}`);
    }

    const application = await response.json();

    return {
        application: application[0],
        message: 'Supplier application submitted successfully',
        nextSteps: [
            'Your application will be reviewed within 3-5 business days',
            'You will receive an email notification once the review is complete',
            'If approved, you can choose a subscription plan to activate your verified status'
        ]
    };
}

async function updateSupplierApplication(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { applicationId, updates } = data;

    // Update application
    const response = await fetch(`${supabaseUrl}/rest/v1/supplier_applications?id=eq.${applicationId}&user_id=eq.${userId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify({
            application_data: updates,
            status: 'submitted', // Reset to submitted for re-review
            updated_at: new Date().toISOString()
        })
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to update application: ${errorText}`);
    }

    const application = await response.json();

    return {
        application: application[0],
        message: 'Application updated successfully'
    };
}

async function createStripeSubscription(supabaseUrl: string, serviceRoleKey: string, stripeSecretKey: string, userId: string, data: any) {
    if (!stripeSecretKey) {
        throw new Error('Stripe configuration missing');
    }

    const { planId, paymentMethodId } = data;

    // Get plan details
    const planResponse = await fetch(`${supabaseUrl}/rest/v1/supplier_plans?id=eq.${planId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const plans = await planResponse.json();
    if (plans.length === 0) {
        throw new Error('Plan not found');
    }

    const plan = plans[0];

    // Get user email for Stripe customer
    const userEmail = userData.email;

    // Create Stripe customer
    const customerParams = new URLSearchParams();
    customerParams.append('email', userEmail);
    customerParams.append('metadata[user_id]', userId);
    customerParams.append('metadata[plan_type]', plan.plan_type);

    const customerResponse = await fetch('https://api.stripe.com/v1/customers', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${stripeSecretKey}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: customerParams.toString()
    });

    if (!customerResponse.ok) {
        const errorData = await customerResponse.text();
        throw new Error(`Stripe customer creation failed: ${errorData}`);
    }

    const customer = await customerResponse.json();

    // Attach payment method to customer
    const attachParams = new URLSearchParams();
    attachParams.append('customer', customer.id);

    await fetch(`https://api.stripe.com/v1/payment_methods/${paymentMethodId}/attach`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${stripeSecretKey}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: attachParams.toString()
    });

    // Create subscription
    const subscriptionParams = new URLSearchParams();
    subscriptionParams.append('customer', customer.id);
    subscriptionParams.append('items[0][price_data][currency]', 'usd');
    subscriptionParams.append('items[0][price_data][unit_amount]', (plan.monthly_price * 100).toString());
    subscriptionParams.append('items[0][price_data][product_data][name]', plan.plan_name);
    subscriptionParams.append('items[0][price_data][recurring][interval]', 'month');
    subscriptionParams.append('default_payment_method', paymentMethodId);
    subscriptionParams.append('metadata[user_id]', userId);
    subscriptionParams.append('metadata[plan_id]', planId);

    const subscriptionResponse = await fetch('https://api.stripe.com/v1/subscriptions', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${stripeSecretKey}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: subscriptionParams.toString()
    });

    if (!subscriptionResponse.ok) {
        const errorData = await subscriptionResponse.text();
        throw new Error(`Stripe subscription creation failed: ${errorData}`);
    }

    const subscription = await subscriptionResponse.json();

    // Get supplier ID
    const supplierResponse = await fetch(`${supabaseUrl}/rest/v1/verified_suppliers?user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const suppliers = await supplierResponse.json();
    if (suppliers.length === 0) {
        throw new Error('Supplier profile not found');
    }

    const supplierId = suppliers[0].id;

    // Save subscription to database
    const subscriptionData = {
        supplier_id: supplierId,
        plan_id: planId,
        stripe_subscription_id: subscription.id,
        stripe_customer_id: customer.id,
        status: subscription.status,
        current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
        current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
        created_at: new Date().toISOString()
    };

    const dbResponse = await fetch(`${supabaseUrl}/rest/v1/supplier_subscriptions`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(subscriptionData)
    });

    if (!dbResponse.ok) {
        const errorText = await dbResponse.text();
        console.error('Failed to save subscription to database:', errorText);
    }

    const dbSubscription = await dbResponse.json();

    return {
        subscription: dbSubscription[0],
        stripeSubscription: subscription,
        message: 'Subscription created successfully'
    };
}

async function cancelSubscription(supabaseUrl: string, serviceRoleKey: string, stripeSecretKey: string, userId: string, data: any) {
    const { subscriptionId } = data;

    // Get subscription from database
    const subscriptionResponse = await fetch(
        `${supabaseUrl}/rest/v1/supplier_subscriptions?id=eq.${subscriptionId}&supplier_id=eq.(select id from verified_suppliers where user_id = '${userId}')`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const subscriptions = await subscriptionResponse.json();
    if (subscriptions.length === 0) {
        throw new Error('Subscription not found');
    }

    const subscription = subscriptions[0];

    // Cancel Stripe subscription
    if (stripeSecretKey && subscription.stripe_subscription_id) {
        await fetch(`https://api.stripe.com/v1/subscriptions/${subscription.stripe_subscription_id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${stripeSecretKey}`
            }
        });
    }

    // Update database
    await fetch(`${supabaseUrl}/rest/v1/supplier_subscriptions?id=eq.${subscriptionId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            status: 'cancelled',
            auto_renew: false,
            updated_at: new Date().toISOString()
        })
    });

    return {
        message: 'Subscription cancelled successfully',
        subscriptionId
    };
}

async function getVerificationStatus(supabaseUrl: string, serviceRoleKey: string, userId: string) {
    // Get supplier info
    const supplierResponse = await fetch(`${supabaseUrl}/rest/v1/verified_suppliers?user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const suppliers = await supplierResponse.json();

    // Get applications
    const applicationResponse = await fetch(`${supabaseUrl}/rest/v1/supplier_applications?user_id=eq.${userId}&order=created_at.desc`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const applications = await applicationResponse.json();

    // Get active subscription
    let subscription = null;
    if (suppliers.length > 0) {
        const subscriptionResponse = await fetch(
            `${supabaseUrl}/rest/v1/supplier_subscriptions?supplier_id=eq.${suppliers[0].id}&status=eq.active`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );
        const subscriptions = await subscriptionResponse.json();
        subscription = subscriptions[0] || null;
    }

    return {
        supplier: suppliers[0] || null,
        latestApplication: applications[0] || null,
        activeSubscription: subscription,
        verificationStatus: suppliers[0]?.verification_status || 'not_applied',
        trustScore: suppliers[0]?.trust_score || null
    };
}

async function submitProduct(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    // Get supplier ID
    const supplierResponse = await fetch(`${supabaseUrl}/rest/v1/verified_suppliers?user_id=eq.${userId}&verification_status=eq.approved`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const suppliers = await supplierResponse.json();
    if (suppliers.length === 0) {
        throw new Error('You must be a verified supplier to submit products');
    }

    const supplierId = suppliers[0].id;

    const productData = {
        supplier_id: supplierId,
        ...data,
        created_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/supplier_products`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(productData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to submit product: ${errorText}`);
    }

    const product = await response.json();

    return {
        product: product[0],
        message: 'Product submitted successfully'
    };
}

async function updateTrustScore(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { supplierId, newScore, reason } = data;

    // Update trust score
    const response = await fetch(`${supabaseUrl}/rest/v1/verified_suppliers?id=eq.${supplierId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            trust_score: newScore,
            updated_at: new Date().toISOString()
        })
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to update trust score: ${errorText}`);
    }

    return {
        message: 'Trust score updated successfully',
        newScore,
        reason
    };
}