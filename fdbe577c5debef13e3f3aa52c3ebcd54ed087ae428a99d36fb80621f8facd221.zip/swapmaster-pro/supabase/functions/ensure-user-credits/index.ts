Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('No authorization header');
        }

        const token = authHeader.replace('Bearer ', '');

        // Verify token and get user
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        console.log('Ensuring credits for user:', userId);

        // Check if user already has credits
        const checkCreditsResponse = await fetch(
            `${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}&select=*`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        const existingCredits = await checkCreditsResponse.json();
        
        if (existingCredits && existingCredits.length > 0) {
            // User already has credits, return current balance
            const userCredits = existingCredits[0];
            return new Response(JSON.stringify({
                data: {
                    success: true,
                    message: 'User already has credits',
                    creditsRemaining: userCredits.credits_remaining,
                    totalEarnedCredits: userCredits.total_earned_credits,
                    isNewUser: false
                }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
        }

        // Create new user credits with 3 free credits
        const createCreditsResponse = await fetch(
            `${supabaseUrl}/rest/v1/user_credits`,
            {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    user_id: userId,
                    credits_remaining: 3,
                    total_credits_used: 0,
                    total_earned_credits: 3,
                    last_credit_purchase: new Date().toISOString(),
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString()
                })
            }
        );

        if (!createCreditsResponse.ok) {
            const errorText = await createCreditsResponse.text();
            console.error('Failed to create credits:', errorText);
            throw new Error(`Failed to create user credits: ${errorText}`);
        }

        const newCredits = await createCreditsResponse.json();
        console.log('Created credits for new user:', newCredits);

        return new Response(JSON.stringify({
            data: {
                success: true,
                message: 'Welcome! You received 3 free credits to try SwapMaster Pro',
                creditsRemaining: 3,
                totalEarnedCredits: 3,
                isNewUser: true
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Ensure user credits error:', error);

        const errorResponse = {
            error: {
                code: 'ENSURE_CREDITS_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});