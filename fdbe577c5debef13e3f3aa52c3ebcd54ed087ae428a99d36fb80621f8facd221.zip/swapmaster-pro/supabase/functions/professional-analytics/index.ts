// Professional Analytics and Bulk Credit System
// B2B dashboard features and bulk credit purchasing for tuner shops

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, ...actionData } = await req.json();

        console.log('Professional analytics action:', action);

        // Get environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('Authorization required');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid authentication token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        let result = null;

        switch (action) {
            case 'get_business_analytics':
                result = await getBusinessAnalytics(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'create_customer_project':
                result = await createCustomerProject(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'update_project_progress':
                result = await updateProjectProgress(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'purchase_bulk_credits':
                result = await purchaseBulkCredits(supabaseUrl, serviceRoleKey, stripeSecretKey, userId, actionData);
                break;
            case 'get_customer_insights':
                result = await getCustomerInsights(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'generate_analytics_report':
                result = await generateAnalyticsReport(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Professional analytics error:', error);

        const errorResponse = {
            error: {
                code: 'PROFESSIONAL_ANALYTICS_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function getBusinessAnalytics(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { dateRange = '30d', metrics = 'all' } = data;

    // Get professional account
    const professionalResponse = await fetch(`${supabaseUrl}/rest/v1/professional_accounts?user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const professionals = await professionalResponse.json();
    if (professionals.length === 0) {
        throw new Error('Professional account not found');
    }

    const professionalId = professionals[0].id;

    // Calculate date range
    const endDate = new Date();
    const startDate = new Date();
    
    switch (dateRange) {
        case '7d':
            startDate.setDate(endDate.getDate() - 7);
            break;
        case '30d':
            startDate.setDate(endDate.getDate() - 30);
            break;
        case '90d':
            startDate.setDate(endDate.getDate() - 90);
            break;
        case '1y':
            startDate.setFullYear(endDate.getFullYear() - 1);
            break;
        default:
            startDate.setDate(endDate.getDate() - 30);
    }

    // Get analytics data
    const analyticsResponse = await fetch(
        `${supabaseUrl}/rest/v1/business_analytics?professional_id=eq.${professionalId}&metric_date=gte.${startDate.toISOString().split('T')[0]}&metric_date=lte.${endDate.toISOString().split('T')[0]}&order=metric_date.asc`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const analytics = await analyticsResponse.json();

    // Get current projects
    const projectsResponse = await fetch(
        `${supabaseUrl}/rest/v1/customer_projects?professional_id=eq.${professionalId}&project_status=not.eq.completed&order=created_at.desc`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const activeProjects = await projectsResponse.json();

    // Calculate summary metrics
    const totalRevenue = analytics.reduce((sum, day) => sum + (parseFloat(day.revenue_generated) || 0), 0);
    const totalProjects = analytics.reduce((sum, day) => sum + (day.completed_projects || 0), 0);
    const avgProjectValue = totalProjects > 0 ? totalRevenue / totalProjects : 0;
    const avgSatisfaction = analytics.length > 0 
        ? analytics.reduce((sum, day) => sum + (parseFloat(day.customer_satisfaction) || 0), 0) / analytics.length 
        : 0;

    // Get top services
    const serviceCount = {};
    analytics.forEach(day => {
        if (day.most_popular_service) {
            serviceCount[day.most_popular_service] = (serviceCount[day.most_popular_service] || 0) + 1;
        }
    });

    const topServices = Object.entries(serviceCount)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 5)
        .map(([service, count]) => ({ service, count }));

    return {
        dateRange: {
            startDate: startDate.toISOString().split('T')[0],
            endDate: endDate.toISOString().split('T')[0],
            days: analytics.length
        },
        summary: {
            totalRevenue: Math.round(totalRevenue * 100) / 100,
            totalProjects,
            activeProjects: activeProjects.length,
            avgProjectValue: Math.round(avgProjectValue * 100) / 100,
            avgSatisfaction: Math.round(avgSatisfaction * 100) / 100
        },
        dailyMetrics: analytics,
        activeProjectsList: activeProjects,
        topServices,
        professionalInfo: professionals[0]
    };
}

async function createCustomerProject(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const {
        customerId,
        projectName,
        projectDescription,
        projectType,
        vehicleInfo,
        targetSpecs,
        estimatedCost,
        estimatedDuration
    } = data;

    // Get professional account
    const professionalResponse = await fetch(`${supabaseUrl}/rest/v1/professional_accounts?user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const professionals = await professionalResponse.json();
    if (professionals.length === 0) {
        throw new Error('Professional account not found');
    }

    const professionalId = professionals[0].id;

    const projectData = {
        professional_id: professionalId,
        customer_id: customerId,
        project_name: projectName,
        project_description: projectDescription,
        project_type: projectType || 'engine_swap',
        vehicle_info: vehicleInfo || {},
        target_specs: targetSpecs || {},
        project_status: 'quoted',
        estimated_cost: estimatedCost,
        estimated_duration: estimatedDuration,
        progress_percentage: 0,
        created_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/customer_projects`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(projectData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to create project: ${errorText}`);
    }

    const project = await response.json();

    return {
        project: project[0],
        message: 'Customer project created successfully'
    };
}

async function updateProjectProgress(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const {
        projectId,
        updateType,
        title,
        description,
        progressPercentage,
        images,
        partsUsed,
        timeSpent,
        costIncurred
    } = data;

    // Verify project ownership
    const projectResponse = await fetch(
        `${supabaseUrl}/rest/v1/customer_projects?id=eq.${projectId}&professional_id=eq.(select id from professional_accounts where user_id = '${userId}')`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const projects = await projectResponse.json();
    if (projects.length === 0) {
        throw new Error('Project not found or access denied');
    }

    // Create project update
    const updateData = {
        project_id: projectId,
        update_type: updateType || 'progress',
        title,
        description,
        progress_percentage: progressPercentage,
        images: images || [],
        parts_used: partsUsed || [],
        time_spent: timeSpent,
        cost_incurred: costIncurred,
        is_customer_visible: true,
        created_at: new Date().toISOString()
    };

    const updateResponse = await fetch(`${supabaseUrl}/rest/v1/project_updates`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(updateData)
    });

    if (!updateResponse.ok) {
        const errorText = await updateResponse.text();
        throw new Error(`Failed to create update: ${errorText}`);
    }

    const update = await updateResponse.json();

    // Update project progress if provided
    if (progressPercentage !== undefined) {
        const projectUpdateData = {
            progress_percentage: progressPercentage,
            updated_at: new Date().toISOString()
        };

        if (progressPercentage === 100) {
            projectUpdateData.project_status = 'completed';
            projectUpdateData.completion_date = new Date().toISOString().split('T')[0];
        }

        await fetch(`${supabaseUrl}/rest/v1/customer_projects?id=eq.${projectId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(projectUpdateData)
        });
    }

    return {
        update: update[0],
        message: 'Project progress updated successfully'
    };
}

async function purchaseBulkCredits(supabaseUrl: string, serviceRoleKey: string, stripeSecretKey: string, userId: string, data: any) {
    const { creditPackage, paymentMethodId } = data;

    if (!stripeSecretKey) {
        throw new Error('Stripe configuration missing');
    }

    // Define credit packages with professional discounts
    const creditPackages = {
        '500_credits': { credits: 500, basePrice: 50.00, proDiscount: 0.20 },
        '1000_credits': { credits: 1000, basePrice: 90.00, proDiscount: 0.25 },
        '5000_credits': { credits: 5000, basePrice: 400.00, proDiscount: 0.30 }
    };

    const packageInfo = creditPackages[creditPackage];
    if (!packageInfo) {
        throw new Error('Invalid credit package');
    }

    // Check if user has professional account for discount
    const professionalResponse = await fetch(`${supabaseUrl}/rest/v1/professional_accounts?user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const professionals = await professionalResponse.json();
    const isProfessional = professionals.length > 0;
    
    // Get professional subscription for additional discount
    let additionalDiscount = 0;
    if (isProfessional) {
        const subscriptionResponse = await fetch(
            `${supabaseUrl}/rest/v1/professional_subscriptions?professional_id=eq.${professionals[0].id}&status=eq.active`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            }
        );
        const subscriptions = await subscriptionResponse.json();
        if (subscriptions.length > 0) {
            // Get plan discount
            const planResponse = await fetch(`${supabaseUrl}/rest/v1/professional_plans?id=eq.${subscriptions[0].plan_id}`, {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            const plans = await planResponse.json();
            if (plans.length > 0) {
                additionalDiscount = parseFloat(plans[0].bulk_credit_discount) || 0;
            }
        }
    }

    const totalDiscount = isProfessional ? Math.max(packageInfo.proDiscount, additionalDiscount) : 0;
    const finalPrice = packageInfo.basePrice * (1 - totalDiscount);

    // Create Stripe payment intent
    const paymentParams = new URLSearchParams();
    paymentParams.append('amount', Math.round(finalPrice * 100).toString()); // Convert to cents
    paymentParams.append('currency', 'usd');
    paymentParams.append('payment_method', paymentMethodId);
    paymentParams.append('confirmation_method', 'manual');
    paymentParams.append('confirm', 'true');
    paymentParams.append('metadata[user_id]', userId);
    paymentParams.append('metadata[credit_package]', creditPackage);
    paymentParams.append('metadata[credits]', packageInfo.credits.toString());
    paymentParams.append('metadata[discount_applied]', totalDiscount.toString());

    const paymentResponse = await fetch('https://api.stripe.com/v1/payment_intents', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${stripeSecretKey}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: paymentParams.toString()
    });

    if (!paymentResponse.ok) {
        const errorData = await paymentResponse.text();
        throw new Error(`Stripe payment failed: ${errorData}`);
    }

    const paymentIntent = await paymentResponse.json();

    if (paymentIntent.status === 'succeeded') {
        // Record bulk purchase
        const purchaseData = {
            user_id: userId,
            professional_id: isProfessional ? professionals[0].id : null,
            credit_package: creditPackage,
            credits_purchased: packageInfo.credits,
            price_paid: finalPrice,
            discount_applied: totalDiscount,
            stripe_payment_intent_id: paymentIntent.id,
            purchase_status: 'completed',
            created_at: new Date().toISOString()
        };

        const purchaseResponse = await fetch(`${supabaseUrl}/rest/v1/bulk_credit_purchases`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify(purchaseData)
        });

        if (!purchaseResponse.ok) {
            const errorText = await purchaseResponse.text();
            console.error('Failed to record bulk purchase:', errorText);
        }

        // Update user credits
        await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                credits_balance: `credits_balance + ${packageInfo.credits}`,
                updated_at: new Date().toISOString()
            })
        });

        const purchase = purchaseResponse.ok ? await purchaseResponse.json() : null;

        return {
            purchase: purchase?.[0],
            paymentIntent,
            creditsAdded: packageInfo.credits,
            totalPaid: finalPrice,
            discountApplied: totalDiscount,
            message: 'Bulk credits purchased successfully'
        };
    } else {
        throw new Error(`Payment not completed: ${paymentIntent.status}`);
    }
}

async function getCustomerInsights(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { timeframe = '90d' } = data;

    // Get professional account
    const professionalResponse = await fetch(`${supabaseUrl}/rest/v1/professional_accounts?user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const professionals = await professionalResponse.json();
    if (professionals.length === 0) {
        throw new Error('Professional account not found');
    }

    const professionalId = professionals[0].id;

    // Get customer projects for insights
    const projectsResponse = await fetch(
        `${supabaseUrl}/rest/v1/customer_projects?professional_id=eq.${professionalId}&order=created_at.desc`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const projects = await projectsResponse.json();

    // Analyze customer preferences
    const serviceTypes = {};
    const vehicleMakes = {};
    const budgetRanges = { low: 0, medium: 0, high: 0 };
    const projectStatuses = {};

    projects.forEach(project => {
        // Service types
        const type = project.project_type || 'unknown';
        serviceTypes[type] = (serviceTypes[type] || 0) + 1;

        // Vehicle makes
        const make = project.vehicle_info?.make || 'unknown';
        vehicleMakes[make] = (vehicleMakes[make] || 0) + 1;

        // Budget ranges
        const cost = parseFloat(project.estimated_cost) || 0;
        if (cost < 5000) budgetRanges.low++;
        else if (cost < 15000) budgetRanges.medium++;
        else budgetRanges.high++;

        // Project statuses
        const status = project.project_status;
        projectStatuses[status] = (projectStatuses[status] || 0) + 1;
    });

    // Calculate conversion rate
    const quotedProjects = projectStatuses.quoted || 0;
    const approvedProjects = (projectStatuses.approved || 0) + (projectStatuses.in_progress || 0) + (projectStatuses.completed || 0);
    const conversionRate = quotedProjects > 0 ? (approvedProjects / quotedProjects) * 100 : 0;

    return {
        totalProjects: projects.length,
        conversionRate: Math.round(conversionRate * 10) / 10,
        insights: {
            mostPopularServices: Object.entries(serviceTypes)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 5)
                .map(([service, count]) => ({ service, count })),
            topVehicleMakes: Object.entries(vehicleMakes)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 5)
                .map(([make, count]) => ({ make, count })),
            budgetDistribution: budgetRanges,
            projectStatusBreakdown: projectStatuses
        },
        recommendations: generateRecommendations(serviceTypes, vehicleMakes, conversionRate)
    };
}

async function generateAnalyticsReport(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { reportType = 'monthly', format = 'summary' } = data;

    // Get comprehensive analytics data
    const analyticsData = await getBusinessAnalytics(supabaseUrl, serviceRoleKey, userId, { dateRange: '30d' });
    const customerInsights = await getCustomerInsights(supabaseUrl, serviceRoleKey, userId, { timeframe: '90d' });

    const report = {
        generatedAt: new Date().toISOString(),
        reportType,
        period: analyticsData.dateRange,
        executiveSummary: {
            totalRevenue: analyticsData.summary.totalRevenue,
            projectsCompleted: analyticsData.summary.totalProjects,
            activeProjects: analyticsData.summary.activeProjects,
            avgProjectValue: analyticsData.summary.avgProjectValue,
            customerSatisfaction: analyticsData.summary.avgSatisfaction,
            conversionRate: customerInsights.conversionRate
        },
        performanceMetrics: analyticsData.dailyMetrics,
        customerAnalysis: customerInsights.insights,
        recommendations: [
            ...customerInsights.recommendations,
            ...generateBusinessRecommendations(analyticsData.summary)
        ],
        topServices: analyticsData.topServices,
        businessGrowthIndicators: calculateGrowthIndicators(analyticsData.dailyMetrics)
    };

    return {
        report,
        message: 'Analytics report generated successfully',
        downloadUrl: null // In real implementation, would generate downloadable PDF
    };
}

function generateRecommendations(serviceTypes: any, vehicleMakes: any, conversionRate: number) {
    const recommendations = [];

    // Service recommendations
    const topService = Object.keys(serviceTypes).reduce((a, b) => serviceTypes[a] > serviceTypes[b] ? a : b, '');
    if (topService) {
        recommendations.push(`Focus marketing efforts on ${topService} services as they represent your strongest offering`);
    }

    // Conversion rate recommendations
    if (conversionRate < 30) {
        recommendations.push('Consider improving your quote presentation or follow-up process to increase conversion rates');
    } else if (conversionRate > 70) {
        recommendations.push('Excellent conversion rate! Consider raising prices or expanding capacity');
    }

    // Vehicle specialization
    const topMake = Object.keys(vehicleMakes).reduce((a, b) => vehicleMakes[a] > vehicleMakes[b] ? a : b, '');
    if (topMake && topMake !== 'unknown') {
        recommendations.push(`Consider becoming a certified specialist for ${topMake} vehicles`);
    }

    return recommendations;
}

function generateBusinessRecommendations(summary: any) {
    const recommendations = [];

    if (summary.avgProjectValue < 5000) {
        recommendations.push('Consider offering premium service packages to increase average project value');
    }

    if (summary.avgSatisfaction < 4.0) {
        recommendations.push('Focus on improving customer communication and project delivery processes');
    }

    if (summary.activeProjects > 20) {
        recommendations.push('Consider hiring additional staff or implementing project management tools');
    }

    return recommendations;
}

function calculateGrowthIndicators(dailyMetrics: any[]) {
    if (dailyMetrics.length < 14) {
        return { trend: 'insufficient_data', weekOverWeek: null };
    }

    const recentWeek = dailyMetrics.slice(-7);
    const previousWeek = dailyMetrics.slice(-14, -7);

    const recentRevenue = recentWeek.reduce((sum, day) => sum + (parseFloat(day.revenue_generated) || 0), 0);
    const previousRevenue = previousWeek.reduce((sum, day) => sum + (parseFloat(day.revenue_generated) || 0), 0);

    const growthRate = previousRevenue > 0 ? ((recentRevenue - previousRevenue) / previousRevenue) * 100 : 0;

    return {
        trend: growthRate > 5 ? 'growing' : growthRate < -5 ? 'declining' : 'stable',
        weekOverWeek: Math.round(growthRate * 10) / 10,
        recentWeekRevenue: Math.round(recentRevenue * 100) / 100,
        previousWeekRevenue: Math.round(previousRevenue * 100) / 100
    };
}