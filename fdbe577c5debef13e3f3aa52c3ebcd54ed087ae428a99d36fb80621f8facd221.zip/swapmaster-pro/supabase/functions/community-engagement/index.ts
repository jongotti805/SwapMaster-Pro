// Community Engagement System
// Handles build threads, voting, achievements, and reward distribution

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, ...actionData } = await req.json();

        console.log('Community engagement action:', action);

        // Get environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('Authorization required');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid authentication token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        let result = null;

        switch (action) {
            case 'create_thread':
                result = await createBuildThread(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'vote_thread':
                result = await voteOnThread(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'add_comment':
                result = await addComment(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'mark_helpful':
                result = await markCommentHelpful(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'follow_user':
                result = await followUser(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'award_achievement':
                result = await awardAchievement(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Community engagement error:', error);

        const errorResponse = {
            error: {
                code: 'COMMUNITY_ENGAGEMENT_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function createBuildThread(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { title, content, threadType, vehicleInfo, buildStage, images, tags } = data;

    const threadData = {
        user_id: userId,
        title,
        content,
        thread_type: threadType || 'build_progress',
        vehicle_info: vehicleInfo || {},
        build_stage: buildStage || 'planning',
        images: images || [],
        tags: tags || [],
        created_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/build_threads`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(threadData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to create thread: ${errorText}`);
    }

    const thread = await response.json();

    // Award credits for posting
    await awardCredits(supabaseUrl, serviceRoleKey, userId, 'post_build_thread', 2, thread[0].id);

    return {
        thread: thread[0],
        creditsAwarded: 2,
        message: 'Build thread created successfully'
    };
}

async function voteOnThread(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { threadId, voteType } = data; // 'upvote' or 'downvote'

    // Check if user has already voted
    const existingVoteResponse = await fetch(
        `${supabaseUrl}/rest/v1/build_thread_votes?user_id=eq.${userId}&thread_id=eq.${threadId}`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const existingVotes = await existingVoteResponse.json();
    
    if (existingVotes.length > 0) {
        // Update existing vote
        if (existingVotes[0].vote_type === voteType) {
            // Remove vote if same type
            await fetch(`${supabaseUrl}/rest/v1/build_thread_votes?id=eq.${existingVotes[0].id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            return { action: 'vote_removed', voteType };
        } else {
            // Update vote type
            await fetch(`${supabaseUrl}/rest/v1/build_thread_votes?id=eq.${existingVotes[0].id}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ vote_type: voteType })
            });
            return { action: 'vote_updated', voteType };
        }
    } else {
        // Create new vote
        await fetch(`${supabaseUrl}/rest/v1/build_thread_votes`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                thread_id: threadId,
                vote_type: voteType
            })
        });

        // Award credits to thread author for upvotes
        if (voteType === 'upvote') {
            // Get thread author
            const threadResponse = await fetch(
                `${supabaseUrl}/rest/v1/build_threads?id=eq.${threadId}&select=user_id`,
                {
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey
                    }
                }
            );
            const threads = await threadResponse.json();
            if (threads.length > 0) {
                await awardCredits(supabaseUrl, serviceRoleKey, threads[0].user_id, 'upvote_received', 1, threadId);
            }
        }

        return { action: 'vote_created', voteType };
    }
}

async function addComment(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { threadId, content, images, parentCommentId } = data;

    const commentData = {
        thread_id: threadId,
        user_id: userId,
        parent_comment_id: parentCommentId || null,
        content,
        images: images || [],
        created_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/build_thread_comments`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(commentData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to add comment: ${errorText}`);
    }

    const comment = await response.json();
    return {
        comment: comment[0],
        message: 'Comment added successfully'
    };
}

async function markCommentHelpful(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { commentId } = data;

    // Mark comment as helpful
    await fetch(`${supabaseUrl}/rest/v1/build_thread_comments?id=eq.${commentId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ is_helpful: true })
    });

    // Award credits to comment author
    const commentResponse = await fetch(
        `${supabaseUrl}/rest/v1/build_thread_comments?id=eq.${commentId}&select=user_id`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );
    const comments = await commentResponse.json();
    if (comments.length > 0) {
        await awardCredits(supabaseUrl, serviceRoleKey, comments[0].user_id, 'helpful_comment', 1, commentId);
    }

    return { message: 'Comment marked as helpful', creditsAwarded: 1 };
}

async function followUser(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { followingId } = data;

    if (userId === followingId) {
        throw new Error('Cannot follow yourself');
    }

    // Check if already following
    const existingFollowResponse = await fetch(
        `${supabaseUrl}/rest/v1/user_follows?follower_id=eq.${userId}&following_id=eq.${followingId}`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const existingFollows = await existingFollowResponse.json();
    
    if (existingFollows.length > 0) {
        // Unfollow
        await fetch(`${supabaseUrl}/rest/v1/user_follows?id=eq.${existingFollows[0].id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        return { action: 'unfollowed', followingId };
    } else {
        // Follow
        await fetch(`${supabaseUrl}/rest/v1/user_follows`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                follower_id: userId,
                following_id: followingId
            })
        });
        return { action: 'followed', followingId };
    }
}

async function awardAchievement(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { achievementType, achievementName, description, points } = data;

    // Check if user already has this achievement
    const existingResponse = await fetch(
        `${supabaseUrl}/rest/v1/user_achievements?user_id=eq.${userId}&achievement_type=eq.${achievementType}`,
        {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        }
    );

    const existingAchievements = await existingResponse.json();
    
    if (existingAchievements.length > 0) {
        return { message: 'Achievement already awarded', achievement: existingAchievements[0] };
    }

    // Award new achievement
    const achievementData = {
        user_id: userId,
        achievement_type: achievementType,
        achievement_name: achievementName,
        description,
        points_awarded: points || 0,
        earned_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/user_achievements`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(achievementData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to award achievement: ${errorText}`);
    }

    const achievement = await response.json();
    return {
        message: 'Achievement awarded successfully',
        achievement: achievement[0]
    };
}

async function awardCredits(supabaseUrl: string, serviceRoleKey: string, userId: string, actionType: string, creditsAwarded: number, sourceId?: string) {
    try {
        // Record engagement reward
        const rewardData = {
            user_id: userId,
            action_type: actionType,
            credits_earned: creditsAwarded,
            source_thread_id: sourceId,
            description: `Earned ${creditsAwarded} credits for ${actionType}`,
            created_at: new Date().toISOString()
        };

        await fetch(`${supabaseUrl}/rest/v1/engagement_rewards`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(rewardData)
        });

        // Update user credits balance
        await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                credits_balance: `credits_balance + ${creditsAwarded}`,
                total_earned_credits: `total_earned_credits + ${creditsAwarded}`
            })
        });

        console.log(`Awarded ${creditsAwarded} credits to user ${userId} for ${actionType}`);
    } catch (error) {
        console.error('Failed to award credits:', error);
    }
}