Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { vehicleDescription, modifications, generationSettings } = await req.json();

        if (!vehicleDescription || !modifications) {
            throw new Error('Vehicle description and modifications are required');
        }

        // Get environment variables
        const geminiApiKey = Deno.env.get('GOOGLE_GEMINI_API_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!geminiApiKey || !supabaseUrl || !serviceRoleKey) {
            throw new Error('Missing required environment variables');
        }

        // Get user from auth header (REQUIRED for credit system)
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('Authentication required for AI mockup generation. Please log in to use this feature.');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid authentication token. Please log in again.');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        // Check and deduct credits BEFORE processing
        const creditCheckResponse = await fetch(`${supabaseUrl}/rest/v1/rpc/deduct_user_credits`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id_param: userId,
                feature_name_param: 'ai_mockup',
                credits_to_deduct: 1,
                metadata_param: {
                    vehicle_description: vehicleDescription,
                    modifications: modifications
                }
            })
        });

        if (!creditCheckResponse.ok) {
            throw new Error('Failed to check user credits');
        }

        const creditResult = await creditCheckResponse.json();
        
        if (!creditResult) {
            throw new Error('Insufficient credits. You need 1 credit to generate an AI mockup. Please purchase more credits or subscribe to unlimited plan.');
        }

        // Create optimized prompt for vehicle mockup generation with Google Gemini
        const promptTemplate = `Generate a highly detailed, photorealistic image of a ${vehicleDescription} with the following modifications: ${modifications}. 

Image specifications:
- Professional automotive photography style with exceptional detail and clarity
- High-resolution quality suitable for automotive magazines
- Realistic lighting, shadows, and reflections
- Accurate proportions and automotive details
- Background: ${generationSettings?.background || 'modern garage workshop'}
- Viewing angle: ${generationSettings?.angle || 'three-quarter front view'}
- Lighting style: ${generationSettings?.lighting || 'professional studio lighting'}
- Render style: ${generationSettings?.style || 'photorealistic'}

Ensure the vehicle looks professionally modified, with all modifications clearly visible and realistically integrated. The image should showcase the craftsmanship and attention to detail that automotive enthusiasts would appreciate.`;

        // Create initial database record
        const insertResponse = await fetch(`${supabaseUrl}/rest/v1/ai_mockups`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                user_id: userId,
                vehicle_description: vehicleDescription,
                modifications: modifications,
                generated_prompt: promptTemplate,
                generation_settings: generationSettings || {},
                generation_status: 'pending',
                credits_used: 1,
                is_public: true
            })
        });

        if (!insertResponse.ok) {
            const errorText = await insertResponse.text();
            throw new Error(`Failed to create mockup record: ${errorText}`);
        }

        const mockupRecord = await insertResponse.json();
        const mockupId = mockupRecord[0]?.id;

        try {
            // Generate image using Google Gemini 2.5 Flash Image
            const imageResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent?key=${geminiApiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: promptTemplate
                        }]
                    }],
                    generationConfig: {
                        temperature: 0.4,
                        topK: 32,
                        topP: 1,
                        maxOutputTokens: 4096
                    }
                })
            });

            if (!imageResponse.ok) {
                const errorText = await imageResponse.text();
                console.error('Gemini API error response:', errorText);
                throw new Error(`Google Gemini API error: ${imageResponse.status} - ${errorText}`);
            }

            const imageData = await imageResponse.json();
            console.log('Gemini API response structure:', JSON.stringify(imageData, null, 2));
            
            // Extract image from Gemini response
            const candidates = imageData.candidates;
            if (!candidates || candidates.length === 0) {
                throw new Error('No candidates returned from Gemini API');
            }

            const parts = candidates[0].content?.parts;
            if (!parts || parts.length === 0) {
                throw new Error('No parts found in Gemini API response');
            }

            // Find the inline data part containing the image
            let imageUrl = null;
            let imageBase64 = null;
            for (const part of parts) {
                if (part.inlineData && part.inlineData.mimeType && part.inlineData.mimeType.startsWith('image/')) {
                    imageBase64 = part.inlineData.data;
                    // Convert base64 to data URL for immediate use
                    imageUrl = `data:${part.inlineData.mimeType};base64,${imageBase64}`;
                    break;
                }
            }

            if (!imageUrl) {
                console.error('Full Gemini response:', JSON.stringify(imageData, null, 2));
                throw new Error('No image data found in Gemini API response');
            }

            // Update database record with generated image URL
            const updateResponse = await fetch(`${supabaseUrl}/rest/v1/ai_mockups?id=eq.${mockupId}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    image_url: imageUrl,
                    generation_status: 'completed'
                })
            });

            if (!updateResponse.ok) {
                const errorText = await updateResponse.text();
                console.error('Failed to update mockup record:', errorText);
            }

            return new Response(JSON.stringify({
                data: {
                    mockupId,
                    imageUrl,
                    prompt: promptTemplate,
                    status: 'completed',
                    creditsUsed: 1,
                    generatedBy: 'Google Gemini 2.5 Flash'
                }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });

        } catch (generationError) {
            console.error('Image generation error:', generationError);
            
            // Update database record with error
            await fetch(`${supabaseUrl}/rest/v1/ai_mockups?id=eq.${mockupId}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    generation_status: 'failed'
                })
            });

            throw generationError;
        }

    } catch (error) {
        console.error('AI mockup generation error:', error);

        const errorResponse = {
            error: {
                code: 'MOCKUP_GENERATION_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});
