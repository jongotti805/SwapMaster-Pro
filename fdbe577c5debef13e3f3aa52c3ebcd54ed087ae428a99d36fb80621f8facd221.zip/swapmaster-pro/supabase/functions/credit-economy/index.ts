Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, opportunityId, userId, amount } = await req.json();
        
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        
        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header if not provided
        let currentUserId = userId;
        if (!currentUserId) {
            const authHeader = req.headers.get('authorization');
            if (!authHeader) {
                throw new Error('No authorization header');
            }

            const token = authHeader.replace('Bearer ', '');
            const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'apikey': serviceRoleKey
                }
            });

            if (!userResponse.ok) {
                throw new Error('Invalid token');
            }

            const userData = await userResponse.json();
            currentUserId = userData.id;
        }

        switch (action) {
            case 'get_user_stats':
                return await getUserStats(supabaseUrl, serviceRoleKey, currentUserId, corsHeaders);
            
            case 'earn_credits':
                return await earnCredits(supabaseUrl, serviceRoleKey, currentUserId, opportunityId, corsHeaders);
            
            case 'spend_credits':
                return await spendCredits(supabaseUrl, serviceRoleKey, currentUserId, amount, corsHeaders);
            
            case 'get_leaderboard':
                return await getLeaderboard(supabaseUrl, serviceRoleKey, corsHeaders);
            
            default:
                throw new Error('Invalid action');
        }

    } catch (error) {
        console.error('Credit economy error:', error);
        
        const errorResponse = {
            error: {
                code: 'CREDIT_ECONOMY_FAILED',
                message: error.message
            }
        };
        
        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// Get user stats including credits, level, badges, etc.
async function getUserStats(supabaseUrl, serviceRoleKey, userId, corsHeaders) {
    try {
        // Get user credits
        const creditsResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const credits = await creditsResponse.json();
        const userCredits = credits[0] || { total_credits: 0, level: 1, experience_points: 0 };
        
        // Get user achievements/badges
        const achievementsResponse = await fetch(`${supabaseUrl}/rest/v1/user_achievements?user_id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const achievements = await achievementsResponse.json();
        
        // Get recent transactions
        const transactionsResponse = await fetch(`${supabaseUrl}/rest/v1/credit_transactions?user_id=eq.${userId}&order=created_at.desc&limit=10`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const transactions = await transactionsResponse.json();
        
        // Calculate next level XP (simple formula: level * 1000)
        const nextLevelXP = (userCredits.level + 1) * 1000;
        
        // Get leaderboard position
        const leaderboardResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits?order=total_credits.desc`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const leaderboard = await leaderboardResponse.json();
        const leaderboardPosition = leaderboard.findIndex(user => user.user_id === userId) + 1;
        
        const userStats = {
            totalCredits: userCredits.total_credits,
            level: userCredits.level,
            experiencePoints: userCredits.experience_points,
            nextLevelXP: nextLevelXP,
            leaderboardPosition: leaderboardPosition || 999,
            badges: achievements.map(achievement => ({
                id: achievement.id,
                name: achievement.name,
                description: achievement.description,
                icon: achievement.icon,
                rarity: achievement.rarity,
                earnedAt: achievement.earned_at
            })),
            transactions: transactions.map(tx => ({
                id: tx.id,
                type: tx.transaction_type,
                amount: tx.amount,
                source: tx.source,
                description: tx.description,
                timestamp: tx.created_at
            }))
        };
        
        return new Response(JSON.stringify({ data: userStats }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to get user stats: ${error.message}`);
    }
}

// Award credits for completing opportunities
async function earnCredits(supabaseUrl, serviceRoleKey, userId, opportunityId, corsHeaders) {
    try {
        // Define earning opportunities with their rewards
        const opportunities = {
            'build_thread_post': { credits: 25, xp: 50, description: 'Posted a build thread', cooldown: 86400000 }, // 24 hours
            'technical_guide': { credits: 150, xp: 300, description: 'Created a technical guide', cooldown: 0 },
            'helpful_comment': { credits: 5, xp: 10, description: 'Left a helpful comment', cooldown: 0 },
            'part_review': { credits: 30, xp: 60, description: 'Reviewed a part or supplier', cooldown: 0 },
            'referral_bonus': { credits: 100, xp: 200, description: 'Successful referral', cooldown: 0 }
        };
        
        const opportunity = opportunities[opportunityId];
        if (!opportunity) {
            throw new Error('Invalid opportunity ID');
        }
        
        // Check cooldown if applicable
        if (opportunity.cooldown > 0) {
            const cooldownCheck = await fetch(`${supabaseUrl}/rest/v1/credit_transactions?user_id=eq.${userId}&source=eq.${opportunityId}&created_at=gte.${new Date(Date.now() - opportunity.cooldown).toISOString()}`, {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey
                }
            });
            
            const recentTransactions = await cooldownCheck.json();
            if (recentTransactions.length > 0) {
                throw new Error('Opportunity still on cooldown');
            }
        }
        
        // Record the credit transaction
        const transactionResponse = await fetch(`${supabaseUrl}/rest/v1/credit_transactions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                transaction_type: 'earned',
                amount: opportunity.credits,
                source: opportunityId,
                description: opportunity.description,
                created_at: new Date().toISOString()
            })
        });
        
        if (!transactionResponse.ok) {
            throw new Error('Failed to record transaction');
        }
        
        // Update user credits and XP
        const updateResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                total_credits: `total_credits + ${opportunity.credits}`,
                experience_points: `experience_points + ${opportunity.xp}`,
                updated_at: new Date().toISOString()
            })
        });
        
        if (!updateResponse.ok) {
            throw new Error('Failed to update user credits');
        }
        
        // Check for level up
        const updatedUser = await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const userData = await updatedUser.json();
        const user = userData[0];
        
        // Level up logic (every 1000 XP = 1 level)
        const newLevel = Math.floor(user.experience_points / 1000) + 1;
        if (newLevel > user.level) {
            await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    level: newLevel
                })
            });
        }
        
        return new Response(JSON.stringify({
            data: {
                creditsEarned: opportunity.credits,
                xpEarned: opportunity.xp,
                newLevel: newLevel > user.level ? newLevel : null,
                totalCredits: user.total_credits + opportunity.credits
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to earn credits: ${error.message}`);
    }
}

// Spend credits on services
async function spendCredits(supabaseUrl, serviceRoleKey, userId, amount, corsHeaders) {
    try {
        // Get current user credits
        const creditsResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const credits = await creditsResponse.json();
        const userCredits = credits[0];
        
        if (!userCredits || userCredits.total_credits < amount) {
            throw new Error('Insufficient credits');
        }
        
        // Record the spending transaction
        await fetch(`${supabaseUrl}/rest/v1/credit_transactions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                transaction_type: 'spent',
                amount: -amount,
                source: 'ai_service',
                description: 'AI service usage',
                created_at: new Date().toISOString()
            })
        });
        
        // Deduct credits
        await fetch(`${supabaseUrl}/rest/v1/user_credits?user_id=eq.${userId}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                total_credits: userCredits.total_credits - amount,
                updated_at: new Date().toISOString()
            })
        });
        
        return new Response(JSON.stringify({
            data: {
                remainingCredits: userCredits.total_credits - amount,
                amountSpent: amount
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to spend credits: ${error.message}`);
    }
}

// Get leaderboard data
async function getLeaderboard(supabaseUrl, serviceRoleKey, corsHeaders) {
    try {
        const leaderboardResponse = await fetch(`${supabaseUrl}/rest/v1/user_credits?order=total_credits.desc&limit=50`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey
            }
        });
        
        const leaderboard = await leaderboardResponse.json();
        
        return new Response(JSON.stringify({
            data: leaderboard.map((user, index) => ({
                position: index + 1,
                userId: user.user_id,
                totalCredits: user.total_credits,
                level: user.level,
                experiencePoints: user.experience_points
            }))
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
    } catch (error) {
        throw new Error(`Failed to get leaderboard: ${error.message}`);
    }
}