Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Get environment variables
        const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!stripeSecretKey || !supabaseUrl || !serviceRoleKey) {
            throw new Error('Missing required environment variables');
        }

        const body = await req.text();
        const signature = req.headers.get('stripe-signature');

        if (!signature) {
            throw new Error('Missing Stripe signature');
        }

        // Parse the event (simplified - in production you'd verify the webhook signature)
        const event = JSON.parse(body);

        console.log('Webhook event received:', event.type);

        switch (event.type) {
            case 'checkout.session.completed':
                await handleCheckoutCompleted(event.data.object, supabaseUrl, serviceRoleKey);
                break;
            
            case 'invoice.payment_succeeded':
                await handleInvoicePaymentSucceeded(event.data.object, supabaseUrl, serviceRoleKey);
                break;
            
            case 'customer.subscription.deleted':
                await handleSubscriptionDeleted(event.data.object, supabaseUrl, serviceRoleKey);
                break;
            
            default:
                console.log(`Unhandled event type: ${event.type}`);
        }

        return new Response(JSON.stringify({ received: true }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Webhook error:', error);
        return new Response(JSON.stringify({ error: error.message }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function handleCheckoutCompleted(session: any, supabaseUrl: string, serviceRoleKey: string) {
    const userId = session.metadata?.user_id;
    const planType = session.metadata?.plan_type;
    const credits = parseInt(session.metadata?.credits || '0');

    if (!userId || !planType) {
        console.error('Missing required metadata in checkout session');
        return;
    }

    if (session.mode === 'payment') {
        // One-time credit purchase
        if (credits > 0) {
            // Add credits to user account using the database function
            const response = await fetch(`${supabaseUrl}/rest/v1/rpc/add_user_credits`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    user_id_param: userId,
                    credits_to_add: credits
                })
            });

            if (response.ok) {
                console.log(`Added ${credits} credits to user ${userId}`);
            } else {
                console.error('Failed to add credits:', await response.text());
            }
        }
    } else if (session.mode === 'subscription') {
        // Create subscription record
        const subscriptionData = {
            user_id: userId,
            stripe_subscription_id: session.subscription,
            stripe_customer_id: session.customer,
            price_id: `price_${planType}`,
            status: 'active'
        };

        const response = await fetch(`${supabaseUrl}/rest/v1/gearshift_subscriptions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(subscriptionData)
        });

        if (response.ok) {
            console.log(`Created subscription for user ${userId}`);
        } else {
            console.error('Failed to create subscription:', await response.text());
        }
    }
}

async function handleInvoicePaymentSucceeded(invoice: any, supabaseUrl: string, serviceRoleKey: string) {
    // Update subscription status if needed
    console.log('Invoice payment succeeded:', invoice.subscription);
}

async function handleSubscriptionDeleted(subscription: any, supabaseUrl: string, serviceRoleKey: string) {
    // Update subscription status to cancelled
    const response = await fetch(
        `${supabaseUrl}/rest/v1/gearshift_subscriptions?stripe_subscription_id=eq.${subscription.id}`,
        {
            method: 'PATCH',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: 'cancelled' })
        }
    );

    if (response.ok) {
        console.log(`Cancelled subscription ${subscription.id}`);
    } else {
        console.error('Failed to update subscription status:', await response.text());
    }
}