Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { planType, customerEmail, isSubscription } = await req.json();

        if (!planType) {
            throw new Error('Plan type is required');
        }

        // Get environment variables
        const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!stripeSecretKey || !supabaseUrl || !serviceRoleKey) {
            throw new Error('Missing required environment variables');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('No authorization header');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;
        const userEmail = customerEmail || userData.email;

        // Get plan details from database
        const planResponse = await fetch(
            `${supabaseUrl}/rest/v1/gearshift_plans?plan_type=eq.${planType}`,
            {
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                }
            }
        );

        if (!planResponse.ok) {
            throw new Error('Failed to fetch plan details');
        }

        const plans = await planResponse.json();
        const plan = plans[0];

        if (!plan || !plan.is_active) {
            throw new Error('Invalid or inactive plan');
        }

        // Create or get Stripe customer
        const customerParams = new URLSearchParams();
        customerParams.append('email', userEmail);
        customerParams.append('metadata[user_id]', userId);

        const customerResponse = await fetch('https://api.stripe.com/v1/customers', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${stripeSecretKey}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: customerParams.toString()
        });

        if (!customerResponse.ok) {
            const errorData = await customerResponse.text();
            throw new Error(`Failed to create Stripe customer: ${errorData}`);
        }

        const customer = await customerResponse.json();

        // Create Stripe Checkout session
        const checkoutParams = new URLSearchParams();
        checkoutParams.append('success_url', `${req.headers.get('origin') || 'http://localhost:3000'}/?purchase=success`);
        checkoutParams.append('cancel_url', `${req.headers.get('origin') || 'http://localhost:3000'}/?purchase=cancelled`);
        checkoutParams.append('customer', customer.id);
        checkoutParams.append('metadata[user_id]', userId);
        checkoutParams.append('metadata[plan_type]', planType);
        checkoutParams.append('metadata[credits]', plan.credits.toString());

        if (plan.is_subscription) {
            // Subscription checkout
            checkoutParams.append('mode', 'subscription');
            checkoutParams.append('line_items[0][price_data][currency]', 'usd');
            checkoutParams.append('line_items[0][price_data][unit_amount]', plan.price.toString());
            checkoutParams.append('line_items[0][price_data][product_data][name]', plan.plan_name);
            checkoutParams.append('line_items[0][price_data][product_data][description]', plan.description || '');
            checkoutParams.append('line_items[0][price_data][recurring][interval]', 'month');
            checkoutParams.append('line_items[0][quantity]', '1');
        } else {
            // One-time payment checkout
            checkoutParams.append('mode', 'payment');
            checkoutParams.append('line_items[0][price_data][currency]', 'usd');
            checkoutParams.append('line_items[0][price_data][unit_amount]', plan.price.toString());
            checkoutParams.append('line_items[0][price_data][product_data][name]', plan.plan_name);
            checkoutParams.append('line_items[0][price_data][product_data][description]', plan.description || '');
            checkoutParams.append('line_items[0][quantity]', '1');
        }

        const checkoutResponse = await fetch('https://api.stripe.com/v1/checkout/sessions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${stripeSecretKey}`,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: checkoutParams.toString()
        });

        if (!checkoutResponse.ok) {
            const errorData = await checkoutResponse.text();
            throw new Error(`Failed to create checkout session: ${errorData}`);
        }

        const session = await checkoutResponse.json();

        return new Response(JSON.stringify({
            data: {
                checkoutUrl: session.url,
                sessionId: session.id,
                planType: planType,
                credits: plan.credits,
                price: plan.price / 100 // Convert cents to dollars
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Purchase credits error:', error);

        const errorResponse = {
            error: {
                code: 'PURCHASE_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});