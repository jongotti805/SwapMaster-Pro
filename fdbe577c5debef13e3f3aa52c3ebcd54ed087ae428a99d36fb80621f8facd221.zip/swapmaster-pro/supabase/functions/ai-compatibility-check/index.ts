// AI Compatibility Check System using Google Gemini
// Analyzes engine swap feasibility and provides intelligent suggestions

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { 
            // New free-text search parameters
            carQuery,
            yearRange,
            engineQuery,
            // Legacy support
            vehicle,
            engine,
            currentEngine, 
            targetEngine, 
            vehicleInfo, 
            budget, 
            experienceLevel,
            performanceGoals,
            checkType = 'comprehensive_analysis',
            regionalPricing = 'US',
            includeAdvancedScoring = true
        } = await req.json();

        console.log('AI compatibility check request:', { 
            carQuery,
            yearRange,
            engineQuery,
            vehicle: vehicle || vehicleInfo, 
            engine: engine || targetEngine, 
            currentEngine, 
            targetEngine, 
            vehicleInfo 
        });

        // Support both new free-text search and legacy formats
        let vehicleData = vehicle || vehicleInfo;
        let engineData = engine;

        // Handle new free-text search format
        if (carQuery) {
            vehicleData = await searchVehicleDatabase(carQuery, yearRange);
            if (!vehicleData) {
                throw new Error(`No vehicles found matching "${carQuery}". Try searching for make and model like "BMW M5" or "Mercedes C63"`);
            }
        }

        if (engineQuery && !engineData) {
            engineData = await searchEngineDatabase(engineQuery);
            if (!engineData) {
                throw new Error(`No engines found matching "${engineQuery}". Try searching for engine names like "LS3" or "Coyote 5.0"`);
            }
        }

        // Legacy engine data fallback
        if (!engineData && targetEngine) {
            engineData = {
                name: targetEngine,
                make: 'Unknown',
                model: 'Unknown',
                displacement: 'Unknown',
                horsepower: 0,
                torque: 0,
                difficulty: 'Advanced'
            };
        }
        
        if (!vehicleData || (!engineData && !targetEngine && !engineQuery)) {
            throw new Error('Vehicle and engine information are required. Use carQuery/engineQuery for free-text search or provide structured data.');
        }

        // Get environment variables
        const geminiApiKey = Deno.env.get('GOOGLE_GEMINI_API_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!geminiApiKey) {
            throw new Error('Google Gemini API key not configured');
        }

        // Get user from auth header
        let userId = null;
        const authHeader = req.headers.get('authorization');
        if (authHeader) {
            try {
                const token = authHeader.replace('Bearer ', '');
                const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'apikey': serviceRoleKey
                    }
                });
                if (userResponse.ok) {
                    const userData = await userResponse.json();
                    userId = userData.id;
                }
            } catch (error) {
                console.log('Could not get user from token:', error.message);
            }
        }

        // Enhanced compatibility analysis - use both AI and deterministic logic
        const basicAnalysis = await performBasicCompatibilityAnalysis(vehicleData, engineData, checkType, regionalPricing);
        
        // Prepare enhanced prompt for Gemini AI
        const compatibilityPrompt = `
As an expert automotive engineer specializing in engine swaps, analyze this engine swap scenario and enhance the provided basic analysis with professional insights:

**VEHICLE INFORMATION:**
- Year: ${vehicleData.year}
- Make: ${vehicleData.make}
- Model: ${vehicleData.model}
- Generation: ${vehicleData.generation || 'Unknown'}
- Body Style: ${vehicleData.bodyStyle || 'Unknown'}
- Current Engine: ${currentEngine || vehicleData.originalEngine || 'Unknown'}
- Target Engine: ${engineData.name || targetEngine}

**ENGINE SPECIFICATIONS:**
- Displacement: ${engineData.displacement || 'Unknown'}
- Configuration: ${engineData.configuration || 'Unknown'}
- Horsepower: ${engineData.horsepower || 'Unknown'}
- Torque: ${engineData.torque || 'Unknown'}
- Difficulty: ${engineData.difficulty || 'Advanced'}

**SWAP DETAILS:**
- Budget: $${budget || 'Not specified'}
- Experience Level: ${experienceLevel || 'Intermediate'}
- Performance Goals: ${performanceGoals || 'General performance improvement'}
- Regional Pricing: ${regionalPricing}

**BASIC ANALYSIS PROVIDED:**
${JSON.stringify(basicAnalysis, null, 2)}

Enhance this analysis with professional insights and provide recommendations in this exact JSON format:
{
  "enhancedCompatibilityScore": [0-100 integer],
  "aiInsights": {
    "feasibilityRating": "excellent|good|challenging|not_recommended",
    "difficultyAssessment": "beginner|intermediate|advanced|expert",
    "professionalRecommendations": ["list of expert recommendations"],
    "potentialChallenges": ["specific challenges to expect"],
    "successFactors": ["key factors for success"]
  },
  "enhancedCostBreakdown": {
    "engineComponents": [amount],
    "fuelSystem": [amount],
    "coolingSystem": [amount],
    "transmission": [amount],
    "exhaust": [amount],
    "electrical": [amount],
    "drivetrain": [amount],
    "suspension": [amount],
    "brakes": [amount],
    "performance": [amount],
    "safety": [amount],
    "labor": [amount],
    "contingency": [amount]
  },
  "timelineEstimate": {
    "planning": "[X] weeks",
    "partsAcquisition": "[X] weeks", 
    "installation": "[X] weeks",
    "tuningTesting": "[X] weeks",
    "total": "[X] weeks to [Y] months"
  },
  "compatibilityMatrix": {
    "physicalFitment": [0-100],
    "electricalIntegration": [0-100],
    "transmissionCompatibility": [0-100],
    "coolingRequirements": [0-100],
    "fuelSystemMatch": [0-100],
    "exhaustFitment": [0-100]
  },
  "alternativeEngineOptions": [
    {
      "engine": "alternative engine option",
      "advantages": ["list of advantages"],
      "compatibilityScore": [0-100],
      "estimatedCost": [amount]
    }
  ],
  "professionalWarnings": [
    "critical safety and legal considerations"
  ],
  "expertTips": [
    "professional insights and tips"
  ],
  "marketInsights": {
    "popularityRating": [0-100],
    "resaleImpact": "positive|neutral|negative",
    "insuranceConsiderations": ["insurance implications"],
    "legalCompliance": ["legal requirements"]
  }
}

Focus on enhancing the provided basic analysis with professional insights, realistic 2025 pricing, and practical considerations. Validate and improve the basic analysis where needed.`;

        // Call Google Gemini API
        const geminiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: compatibilityPrompt
                    }]
                }],
                generationConfig: {
                    temperature: 0.2,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 2048
                }
            })
        });

        if (!geminiResponse.ok) {
            const errorData = await geminiResponse.text();
            console.error('Gemini API error:', errorData);
            throw new Error(`Gemini API error: ${errorData}`);
        }

        const geminiData = await geminiResponse.json();
        console.log('Gemini API response received');

        if (!geminiData.candidates || geminiData.candidates.length === 0) {
            throw new Error('No response from AI model');
        }

        const aiText = geminiData.candidates[0].content.parts[0].text;
        
        // Parse JSON from AI response
        let compatibilityAnalysis;
        try {
            const jsonMatch = aiText.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                compatibilityAnalysis = JSON.parse(jsonMatch[0]);
            } else {
                throw new Error('No JSON found in AI response');
            }
        } catch (parseError) {
            console.error('Failed to parse AI response:', parseError);
            // Fallback to text response
            compatibilityAnalysis = {
                compatibilityScore: 75,
                feasibilityRating: 'good',
                difficultyLevel: 'intermediate',
                aiTextResponse: aiText,
                estimatedCost: { minimum: 5000, maximum: 15000 },
                estimatedTimeframe: '2-6 months'
            };
        }

        // Save analysis to database if user is authenticated
        let analysisId = null;
        if (userId && supabaseUrl && serviceRoleKey) {
            try {
                const analysisData = {
                    user_id: userId,
                    current_engine: currentEngine,
                    target_engine: targetEngine,
                    vehicle_info: vehicleInfo,
                    compatibility_analysis: compatibilityAnalysis,
                    budget_range: budget,
                    experience_level: experienceLevel,
                    performance_goals: performanceGoals,
                    created_at: new Date().toISOString()
                };

                const insertResponse = await fetch(`${supabaseUrl}/rest/v1/compatibility_analyses`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify(analysisData)
                });

                if (insertResponse.ok) {
                    const insertData = await insertResponse.json();
                    analysisId = insertData[0]?.id;
                    console.log('Analysis saved to database:', analysisId);
                }
            } catch (dbError) {
                console.error('Failed to save analysis to database:', dbError);
            }
        }

        const result = {
            data: {
                analysisId,
                compatibility: compatibilityAnalysis,
                vehicleInfo,
                swapDetails: {
                    currentEngine,
                    targetEngine,
                    budget,
                    experienceLevel,
                    performanceGoals
                },
                timestamp: new Date().toISOString()
            }
        };

        console.log('Compatibility analysis completed successfully');

        return new Response(JSON.stringify(result), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('AI compatibility check error:', error);

        const errorResponse = {
            error: {
                code: 'AI_COMPATIBILITY_CHECK_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

// Enhanced basic compatibility analysis function
async function performBasicCompatibilityAnalysis(vehicle: any, engine: any, checkType: string, regionalPricing: string) {
    let score = 100;
    let factors = [];
    let issues = [];
    let warnings = [];
    let suggestions = [];

    // Year compatibility analysis
    const currentYear = new Date().getFullYear();
    const yearDiff = Math.abs(currentYear - vehicle.year);
    
    if (yearDiff > 15) {
        score -= 10;
        warnings.push('Older vehicle may require additional modifications for modern engine');
        factors.push({ factor: 'Vehicle Age', impact: -10 });
    }

    // Brand compatibility analysis
    if (vehicle.make && engine.make && vehicle.make.toLowerCase() === engine.make.toLowerCase()) {
        score += 15;
        suggestions.push('Same brand engines typically have better compatibility and support');
        factors.push({ factor: 'Brand Match', impact: 15 });
    } else {
        score -= 5;
        warnings.push('Cross-brand swaps may require additional adapters and modifications');
        factors.push({ factor: 'Cross-Brand Swap', impact: -5 });
    }

    // Power increase analysis
    const estimatedOriginalHP = getEstimatedHP(vehicle.originalEngine || '');
    const powerIncrease = engine.horsepower ? ((engine.horsepower - estimatedOriginalHP) / estimatedOriginalHP) * 100 : 50;
    
    if (powerIncrease > 100) {
        score -= 20;
        warnings.push('Extreme power increase requires comprehensive supporting modifications');
        suggestions.push('Consider full drivetrain, brake, and suspension upgrades');
        factors.push({ factor: 'Extreme Power Increase', impact: -20 });
    } else if (powerIncrease > 50) {
        score -= 10;
        warnings.push('Significant power increase requires supporting modifications');
        suggestions.push('Upgrade brakes, suspension, and cooling systems');
        factors.push({ factor: 'High Power Increase', impact: -10 });
    }

    // Engine configuration compatibility
    if (engine.configuration && engine.configuration.includes('Turbo')) {
        score -= 5;
        suggestions.push('Turbo engines require enhanced cooling and fuel systems');
        factors.push({ factor: 'Turbocharged Engine', impact: -5 });
    }

    if (engine.configuration && engine.configuration.includes('Supercharged')) {
        score -= 8;
        suggestions.push('Supercharged engines require significant cooling and fuel system upgrades');
        factors.push({ factor: 'Supercharged Engine', impact: -8 });
    }

    // Displacement compatibility
    const originalDisplacement = extractDisplacement(vehicle.originalEngine || '');
    const newDisplacement = parseFloat(engine.displacement?.replace('L', '') || '3.0');
    
    if (newDisplacement > originalDisplacement * 1.5) {
        score -= 15;
        warnings.push('Significantly larger engine may require engine bay modifications');
        suggestions.push('Verify hood clearance and modify engine mounts');
        factors.push({ factor: 'Large Displacement Increase', impact: -15 });
    }

    // Difficulty assessment
    const difficultyPenalty = {
        'Easy': 5,
        'Intermediate': 0,
        'Advanced': -10,
        'Expert': -20
    }[engine.difficulty] || -10;
    
    score += difficultyPenalty;
    if (difficultyPenalty !== 0) {
        factors.push({ factor: `${engine.difficulty} Installation Complexity`, impact: difficultyPenalty });
    }

    // Generate comprehensive parts breakdown with 15+ categories
    const partsRequired = generateComprehensivePartsBreakdown(vehicle, engine, powerIncrease);
    
    // Calculate costs with regional adjustment
    const regionalMultiplier = getRegionalMultiplier(regionalPricing);
    const totalCost = partsRequired.reduce((sum, category) => sum + category.estimatedCost, 0) * regionalMultiplier;

    // Additional suggestions based on analysis
    if (powerIncrease > 30) {
        suggestions.push('Professional tuning required for optimal performance and reliability');
    }
    
    suggestions.push('Consider joining enthusiast forums for vehicle-specific advice');
    suggestions.push('Document all modifications for insurance and resale purposes');

    // Determine compatibility result
    const compatible = score >= 40;
    const confidence = Math.max(50, Math.min(100, score));
    
    let fitmentDifficulty: 'Easy' | 'Moderate' | 'Difficult' | 'Expert';
    if (score >= 80) fitmentDifficulty = 'Easy';
    else if (score >= 65) fitmentDifficulty = 'Moderate';
    else if (score >= 45) fitmentDifficulty = 'Difficult';
    else fitmentDifficulty = 'Expert';

    return {
        compatible,
        confidence,
        issues,
        warnings,
        suggestions,
        fitmentDifficulty,
        estimatedCost: `$${Math.round(totalCost).toLocaleString()}`,
        regulatoryNotes: [
            'Check local emissions regulations and inspection requirements',
            'Professional installation strongly recommended for safety',
            'Verify insurance coverage for modified vehicles',
            'Some modifications may void vehicle warranty'
        ],
        partsRequired,
        timeEstimate: `${Math.round(40 + (100 - score) * 0.3)}-${Math.round(70 + (100 - score) * 0.5)} hours`,
        recommendedParts: generateRecommendedParts(vehicle, engine, powerIncrease),
        compatibilityScore: {
            score: confidence,
            factors,
            rating: score >= 85 ? 'Excellent' : score >= 70 ? 'Good' : score >= 55 ? 'Fair' : 'Challenging'
        },
        regionalAdjustment: {
            multiplier: regionalMultiplier,
            currency: getCurrency(regionalPricing),
            note: getRegionalNote(regionalPricing)
        },
        performanceGains: {
            estimatedHorsepower: `${engine.horsepower || 'N/A'} hp`,
            estimatedTorque: `${engine.torque || 'N/A'} lb-ft`,
            powerIncrease: `${Math.round(powerIncrease)}%`,
            quarterMileImprovement: powerIncrease > 50 ? '0.5-1.2 seconds' : '0.2-0.8 seconds'
        }
    };
}

function getEstimatedHP(engineName: string): number {
    if (!engineName) return 200;
    
    // More comprehensive HP estimation patterns
    const hpPatterns = {
        '1.6': 120,
        '1.8': 140,
        '2.0': 180,
        '2.4': 200,
        '2.5': 220,
        '3.0': 250,
        '3.5': 280,
        '3.8': 300,
        '4.0': 350,
        '4.6': 380,
        '5.0': 420,
        '5.2': 450,
        '5.5': 480,
        '6.0': 500,
        '6.2': 450,
        '6.4': 480,
        '7.0': 500
    };
    
    // Check for turbo/supercharged multipliers
    let multiplier = 1;
    if (engineName.toLowerCase().includes('turbo')) multiplier = 1.3;
    if (engineName.toLowerCase().includes('supercharged')) multiplier = 1.4;
    if (engineName.toLowerCase().includes('twin turbo')) multiplier = 1.5;
    
    for (const [displacement, hp] of Object.entries(hpPatterns)) {
        if (engineName.includes(displacement)) {
            return Math.round(hp * multiplier);
        }
    }
    
    return 200;
}

function extractDisplacement(engineName: string): number {
    const match = engineName.match(/(\d+\.\d+)/);
    return match ? parseFloat(match[1]) : 3.0;
}

function generateComprehensivePartsBreakdown(vehicle: any, engine: any, powerIncrease: number) {
    const categories = [
        {
            category: 'Engine Components',
            items: ['Custom engine mounts', 'Engine wiring harness', 'ECU/PCM', 'Engine block assembly', 'Timing components'],
            estimatedCost: 3500 + (powerIncrease > 50 ? 1000 : 0)
        },
        {
            category: 'Fuel System',
            items: ['High-flow fuel pump', 'Fuel lines and fittings', 'Fuel rail', 'High-flow injectors', 'Fuel pressure regulator'],
            estimatedCost: 2200 + (powerIncrease > 60 ? 800 : 0)
        },
        {
            category: 'Cooling System',
            items: ['Performance radiator', 'Water pump', 'Thermostat', 'Cooling fans', 'Hoses and clamps', 'Intercooler'],
            estimatedCost: 1800 + (powerIncrease > 40 ? 600 : 0)
        },
        {
            category: 'Transmission',
            items: ['Transmission adapter', 'Performance clutch kit', 'Flywheel', 'Pilot bearing', 'Transmission mount'],
            estimatedCost: 2400 + (powerIncrease > 70 ? 800 : 0)
        },
        {
            category: 'Exhaust System',
            items: ['Custom headers', 'Downpipe', 'Cat-back exhaust', 'Catalytic converter', 'Heat shields'],
            estimatedCost: 2200
        },
        {
            category: 'Electrical',
            items: ['High-output battery', 'Upgraded alternator', 'Performance starter', 'Wiring upgrades', 'Gauges'],
            estimatedCost: 1200
        },
        {
            category: 'Drivetrain',
            items: ['Custom driveshaft', 'U-joints', 'CV joints', 'Differential components', 'Axles'],
            estimatedCost: 1400 + (powerIncrease > 80 ? 600 : 0)
        },
        {
            category: 'Suspension',
            items: ['Performance springs', 'Upgraded struts/shocks', 'Sway bars', 'Control arms', 'Alignment'],
            estimatedCost: powerIncrease > 40 ? 2000 : 800
        },
        {
            category: 'Brakes',
            items: ['Performance brake pads', 'Upgraded rotors', 'Stainless brake lines', 'Brake fluid', 'Master cylinder'],
            estimatedCost: powerIncrease > 60 ? 2500 : 1200
        },
        {
            category: 'Performance',
            items: ['Cold air intake', 'Throttle body', 'Performance tune', 'Boost controller', 'Intercooler piping'],
            estimatedCost: 1500
        },
        {
            category: 'Interior',
            items: ['Racing seats', 'Harnesses', 'Steering wheel', 'Shift knob', 'Gauges'],
            estimatedCost: 1800
        },
        {
            category: 'Exterior',
            items: ['Hood modifications', 'Front bumper', 'Side skirts', 'Rear spoiler', 'Body kit'],
            estimatedCost: 2200
        },
        {
            category: 'Safety',
            items: ['Roll cage', 'Fire extinguisher', 'Kill switch', 'Window net', 'Safety inspection'],
            estimatedCost: powerIncrease > 70 ? 2800 : 1000
        },
        {
            category: 'Tools & Equipment',
            items: ['Engine hoist', 'Transmission jack', 'Specialty tools', 'Torque wrenches', 'Diagnostic equipment'],
            estimatedCost: 1200
        },
        {
            category: 'Miscellaneous',
            items: ['Fluids and chemicals', 'Hardware and fasteners', 'Gaskets and seals', 'Shop supplies', 'Documentation'],
            estimatedCost: 800
        }
    ];
    
    // Add professional installation category for complex swaps
    if (powerIncrease > 50 || engine.difficulty === 'Expert') {
        categories.push({
            category: 'Professional Installation',
            items: ['Engine removal', 'Installation labor', 'Tuning services', 'Alignment', 'Testing and validation'],
            estimatedCost: 4000 + (powerIncrease > 80 ? 2000 : 0)
        });
    }
    
    return categories;
}

function generateRecommendedParts(vehicle: any, engine: any, powerIncrease: number) {
    const baseParts = [
        {
            name: 'Custom Engine Mount Kit',
            category: 'Engine Components',
            price: 489,
            required: true,
            availability: {
                inStock: true,
                leadTime: 5,
                suppliers: 3,
                priceRange: { min: 400, max: 650 }
            }
        },
        {
            name: 'Standalone Engine Management ECU',
            category: 'Engine Components',
            price: 1899,
            required: true,
            availability: {
                inStock: true,
                leadTime: 3,
                suppliers: 5,
                priceRange: { min: 1500, max: 2800 }
            }
        },
        {
            name: 'High-Performance Fuel Pump',
            category: 'Fuel System',
            price: 399,
            required: true,
            availability: {
                inStock: true,
                leadTime: 2,
                suppliers: 8,
                priceRange: { min: 300, max: 550 }
            }
        },
        {
            name: 'Performance Radiator',
            category: 'Cooling System',
            price: 649,
            required: true,
            availability: {
                inStock: true,
                leadTime: 7,
                suppliers: 4,
                priceRange: { min: 500, max: 800 }
            }
        },
        {
            name: 'Transmission Adapter Kit',
            category: 'Transmission',
            price: 789,
            required: true,
            availability: {
                inStock: false,
                leadTime: 14,
                suppliers: 2,
                priceRange: { min: 600, max: 1200 }
            }
        }
    ];
    
    // Add performance-specific parts for high power swaps
    if (powerIncrease > 50) {
        baseParts.push(
            {
                name: 'Performance Clutch Kit',
                category: 'Transmission',
                price: 899,
                required: true,
                availability: {
                    inStock: true,
                    leadTime: 5,
                    suppliers: 6,
                    priceRange: { min: 700, max: 1200 }
                }
            },
            {
                name: 'Big Brake Kit',
                category: 'Brakes',
                price: 2299,
                required: false,
                availability: {
                    inStock: true,
                    leadTime: 10,
                    suppliers: 3,
                    priceRange: { min: 1800, max: 3000 }
                }
            }
        );
    }
    
    if (powerIncrease > 70) {
        baseParts.push(
            {
                name: 'Coilover Suspension Kit',
                category: 'Suspension',
                price: 1599,
                required: false,
                availability: {
                    inStock: true,
                    leadTime: 7,
                    suppliers: 5,
                    priceRange: { min: 1200, max: 2500 }
                }
            },
            {
                name: 'Roll Cage Kit',
                category: 'Safety',
                price: 1899,
                required: false,
                availability: {
                    inStock: false,
                    leadTime: 21,
                    suppliers: 2,
                    priceRange: { min: 1500, max: 2500 }
                }
            }
        );
    }
    
    return baseParts;
}

// NEW: Fuzzy search functions for free-text vehicle and engine queries

async function searchVehicleDatabase(carQuery: string, yearRange?: {min: number, max: number}): Promise<any | null> {
    try {
        console.log(`Searching vehicles for: "${carQuery}" with year range:`, yearRange);
        
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        
        if (!supabaseUrl || !serviceRoleKey) {
            console.log('Database credentials not available, using fallback search');
            return performFuzzyVehicleSearch(carQuery, yearRange);
        }

        // Parse the query to extract make and model
        const { make, model } = parseVehicleQuery(carQuery);
        
        // Build database query with fuzzy matching
        let query = `make.ilike.*${make}*`;
        if (model) {
            query += `&model.ilike.*${model}*`;
        }
        
        // Add year range filter if provided
        if (yearRange?.min) {
            query += `&start_year.lte.${yearRange.max || new Date().getFullYear()}`;
            query += `&end_year.gte.${yearRange.min}`;
        }
        
        const response = await fetch(`${supabaseUrl}/rest/v1/vehicles?${query}&limit=10`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            console.log('Database query failed, using fallback');
            return performFuzzyVehicleSearch(carQuery, yearRange);
        }
        
        const vehicles = await response.json();
        
        if (vehicles && vehicles.length > 0) {
            // Return the best match (first result)
            const bestMatch = vehicles[0];
            return {
                year: yearRange?.min || bestMatch.start_year || 2020,
                make: bestMatch.make,
                model: bestMatch.model,
                generation: bestMatch.generation || 'Unknown',
                bodyStyle: bestMatch.body_style || 'Unknown',
                originalEngine: bestMatch.original_engine || 'Unknown',
                searchQuery: carQuery
            };
        }
        
        // If no database results, use fuzzy matching
        return performFuzzyVehicleSearch(carQuery, yearRange);
        
    } catch (error) {
        console.error('Vehicle search error:', error);
        return performFuzzyVehicleSearch(carQuery, yearRange);
    }
}

async function searchEngineDatabase(engineQuery: string): Promise<any | null> {
    try {
        console.log(`Searching engines for: "${engineQuery}"`);
        
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        
        if (!supabaseUrl || !serviceRoleKey) {
            console.log('Database credentials not available, using fallback search');
            return performFuzzyEngineSearch(engineQuery);
        }

        // Build database query with fuzzy matching on name, code, and family
        const query = `name.ilike.*${engineQuery}*,code.ilike.*${engineQuery}*,family.ilike.*${engineQuery}*`;
        
        const response = await fetch(`${supabaseUrl}/rest/v1/engines?or=(${query})&limit=10`, {
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            console.log('Database query failed, using fallback');
            return performFuzzyEngineSearch(engineQuery);
        }
        
        const engines = await response.json();
        
        if (engines && engines.length > 0) {
            // Return the best match (first result)
            const bestMatch = engines[0];
            return {
                name: bestMatch.name,
                make: bestMatch.make,
                code: bestMatch.code,
                family: bestMatch.family,
                displacement: bestMatch.displacement,
                configuration: bestMatch.configuration,
                horsepower: bestMatch.horsepower,
                torque: bestMatch.torque,
                difficulty: bestMatch.difficulty || 'Advanced',
                searchQuery: engineQuery
            };
        }
        
        // If no database results, use fuzzy matching
        return performFuzzyEngineSearch(engineQuery);
        
    } catch (error) {
        console.error('Engine search error:', error);
        return performFuzzyEngineSearch(engineQuery);
    }
}

function parseVehicleQuery(query: string): {make: string, model?: string} {
    const cleanQuery = query.trim().toLowerCase();
    
    // Common patterns for vehicle queries
    const patterns = [
        // "BMW M5" -> make: BMW, model: M5
        /^(\w+)\s+([\w\d]+)$/,
        // "Mercedes AMG C63" -> make: Mercedes, model: AMG C63
        /^(\w+)\s+(amg|rs|m)\s*([\w\d]+)$/i,
        // "Ford Mustang GT" -> make: Ford, model: Mustang GT
        /^(\w+)\s+([\w\s]+)$/
    ];
    
    for (const pattern of patterns) {
        const match = cleanQuery.match(pattern);
        if (match) {
            if (match.length === 3) {
                return { make: match[1], model: match[2] };
            } else if (match.length === 4) {
                return { make: match[1], model: `${match[2]} ${match[3]}` };
            }
        }
    }
    
    // Single word - treat as make only
    return { make: cleanQuery };
}

function performFuzzyVehicleSearch(carQuery: string, yearRange?: {min: number, max: number}): any | null {
    // Fallback fuzzy matching for popular vehicles
    const { make, model } = parseVehicleQuery(carQuery);
    const year = yearRange?.min || 2020;
    
    const popularVehicles = {
        'bmw': {
            'm5': { make: 'BMW', model: 'M5', originalEngine: '4.4L Twin Turbo V8' },
            'm3': { make: 'BMW', model: 'M3', originalEngine: '3.0L Twin Turbo I6' },
            'm2': { make: 'BMW', model: 'M2', originalEngine: '3.0L Twin Turbo I6' },
            '335i': { make: 'BMW', model: '335i', originalEngine: '3.0L Twin Turbo I6' },
            '340i': { make: 'BMW', model: '340i', originalEngine: '3.0L Turbo I6' }
        },
        'mercedes': {
            'c63': { make: 'Mercedes-AMG', model: 'C63', originalEngine: '4.0L Twin Turbo V8' },
            'e63': { make: 'Mercedes-AMG', model: 'E63', originalEngine: '4.0L Twin Turbo V8' },
            'amg': { make: 'Mercedes-AMG', model: model?.replace('amg', '').trim() || 'C63', originalEngine: '4.0L Twin Turbo V8' }
        },
        'audi': {
            'rs3': { make: 'Audi', model: 'RS3', originalEngine: '2.5L Turbo I5' },
            'rs6': { make: 'Audi', model: 'RS6', originalEngine: '4.0L Twin Turbo V8' },
            's4': { make: 'Audi', model: 'S4', originalEngine: '3.0L Supercharged V6' }
        },
        'ford': {
            'mustang': { make: 'Ford', model: 'Mustang GT', originalEngine: '5.0L Coyote V8' },
            'f150': { make: 'Ford', model: 'F-150', originalEngine: '3.5L EcoBoost V6' }
        },
        'chevrolet': {
            'camaro': { make: 'Chevrolet', model: 'Camaro SS', originalEngine: '6.2L LT1 V8' },
            'corvette': { make: 'Chevrolet', model: 'Corvette', originalEngine: '6.2L LT2 V8' }
        },
        'dodge': {
            'challenger': { make: 'Dodge', model: 'Challenger', originalEngine: '6.4L HEMI V8' },
            'charger': { make: 'Dodge', model: 'Charger', originalEngine: '6.4L HEMI V8' }
        }
    };
    
    const makeKey = make.toLowerCase();
    const modelKey = model?.toLowerCase().replace(/[\s-]/g, '') || '';
    
    if (popularVehicles[makeKey]) {
        // Try exact model match first
        for (const [key, vehicle] of Object.entries(popularVehicles[makeKey])) {
            if (modelKey.includes(key) || key.includes(modelKey)) {
                return {
                    year,
                    make: vehicle.make,
                    model: vehicle.model,
                    generation: 'Modern',
                    bodyStyle: 'Sedan/Coupe',
                    originalEngine: vehicle.originalEngine,
                    searchQuery: carQuery
                };
            }
        }
        
        // Fallback to first model for the make
        const firstModel = Object.values(popularVehicles[makeKey])[0] as any;
        return {
            year,
            make: firstModel.make,
            model: firstModel.model,
            generation: 'Modern',
            bodyStyle: 'Unknown',
            originalEngine: firstModel.originalEngine,
            searchQuery: carQuery
        };
    }
    
    return null;
}

function performFuzzyEngineSearch(engineQuery: string): any | null {
    // Fallback fuzzy matching for popular engines
    const query = engineQuery.toLowerCase().replace(/[\s.-]/g, '');
    
    const popularEngines = {
        'ls3': { name: 'LS3', make: 'Chevrolet', displacement: '6.2L', horsepower: 430, torque: 424, configuration: 'V8' },
        'ls1': { name: 'LS1', make: 'Chevrolet', displacement: '5.7L', horsepower: 350, torque: 365, configuration: 'V8' },
        'lt1': { name: 'LT1', make: 'Chevrolet', displacement: '6.2L', horsepower: 460, torque: 465, configuration: 'V8' },
        'coyote': { name: 'Coyote 5.0', make: 'Ford', displacement: '5.0L', horsepower: 460, torque: 420, configuration: 'V8' },
        '50coyote': { name: 'Coyote 5.0', make: 'Ford', displacement: '5.0L', horsepower: 460, torque: 420, configuration: 'V8' },
        's58': { name: 'S58', make: 'BMW', displacement: '3.0L', horsepower: 473, torque: 406, configuration: 'Twin Turbo I6' },
        'b58': { name: 'B58', make: 'BMW', displacement: '3.0L', horsepower: 335, torque: 369, configuration: 'Turbo I6' },
        'm177': { name: 'M177', make: 'Mercedes-AMG', displacement: '4.0L', horsepower: 469, torque: 479, configuration: 'Twin Turbo V8' },
        'voodoo': { name: 'Voodoo 5.2', make: 'Ford', displacement: '5.2L', horsepower: 526, torque: 429, configuration: 'Flat-Plane V8' },
        '52voodoo': { name: 'Voodoo 5.2', make: 'Ford', displacement: '5.2L', horsepower: 526, torque: 429, configuration: 'Flat-Plane V8' },
        'hemi': { name: '6.4L HEMI', make: 'Dodge', displacement: '6.4L', horsepower: 485, torque: 475, configuration: 'V8' },
        '64hemi': { name: '6.4L HEMI', make: 'Dodge', displacement: '6.4L', horsepower: 485, torque: 475, configuration: 'V8' }
    };
    
    for (const [key, engine] of Object.entries(popularEngines)) {
        if (query.includes(key) || key.includes(query)) {
            return {
                name: engine.name,
                make: engine.make,
                code: key.toUpperCase(),
                family: engine.name.split(' ')[0],
                displacement: engine.displacement,
                configuration: engine.configuration,
                horsepower: engine.horsepower,
                torque: engine.torque,
                difficulty: 'Advanced',
                searchQuery: engineQuery
            };
        }
    }
    
    return null;
}

function getRegionalMultiplier(region: string): number {
    const multipliers = {
        'US': 1.0,
        'EU': 1.35,
        'UK': 1.25, 
        'CA': 1.15,
        'AU': 1.4,
        'JP': 1.3
    };
    return multipliers[region] || 1.0;
}

function getCurrency(region: string): string {
    const currencies = {
        'US': 'USD',
        'EU': 'EUR',
        'UK': 'GBP',
        'CA': 'CAD', 
        'AU': 'AUD',
        'JP': 'JPY'
    };
    return currencies[region] || 'USD';
}

function getRegionalNote(region: string): string {
    const notes = {
        'US': 'Base US pricing excluding shipping and taxes',
        'EU': 'Includes VAT and estimated import duties',
        'UK': 'Includes VAT, excludes shipping',
        'CA': 'Canadian pricing including taxes',
        'AU': 'Australian pricing with import costs and GST',
        'JP': 'Japanese pricing including consumption tax'
    };
    return notes[region] || 'Base pricing excluding taxes and shipping';
}ceRange: { min: 1500, max: 3000 }
                }
            }
        );
    }
    
    return baseParts;
}

function getRegionalMultiplier(region: string): number {
    const multipliers = {
        'US': 1.0,
        'EU': 1.35,
        'UK': 1.25,
        'CA': 1.15,
        'AU': 1.4,
        'JP': 1.3
    };
    return multipliers[region] || 1.0;
}

function getCurrency(region: string): string {
    const currencies = {
        'US': 'USD',
        'EU': 'EUR',
        'UK': 'GBP',
        'CA': 'CAD',
        'AU': 'AUD',
        'JP': 'JPY'
    };
    return currencies[region] || 'USD';
}

function getRegionalNote(region: string): string {
    const notes = {
        'US': 'Base US pricing excluding shipping and taxes',
        'EU': 'Includes VAT and estimated import duties',
        'UK': 'Includes VAT, excludes shipping',
        'CA': 'Canadian pricing including taxes',
        'AU': 'Australian pricing with import costs and GST',
        'JP': 'Japanese pricing including consumption tax'
    };
    return notes[region] || 'Base pricing excluding taxes and shipping';
}