// AR Visualization System
// Processes AR mockup data and integrates with AI-generated overlays

Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { action, ...actionData } = await req.json();

        console.log('AR visualization action:', action);

        // Get environment variables
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const geminiApiKey = Deno.env.get('GOOGLE_GEMINI_API_KEY');

        if (!supabaseUrl || !serviceRoleKey) {
            throw new Error('Supabase configuration missing');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        if (!authHeader) {
            throw new Error('Authorization required');
        }

        const token = authHeader.replace('Bearer ', '');
        const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'apikey': serviceRoleKey
            }
        });

        if (!userResponse.ok) {
            throw new Error('Invalid authentication token');
        }

        const userData = await userResponse.json();
        const userId = userData.id;

        let result = null;

        switch (action) {
            case 'generate_ar_mockup':
                result = await generateARMockup(supabaseUrl, serviceRoleKey, geminiApiKey, userId, actionData);
                break;
            case 'save_ar_session':
                result = await saveARSession(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'process_ar_image':
                result = await processARImage(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'get_ar_mockups':
                result = await getARMockups(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            case 'update_mockup_visibility':
                result = await updateMockupVisibility(supabaseUrl, serviceRoleKey, userId, actionData);
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }

        return new Response(JSON.stringify({ data: result }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('AR visualization error:', error);

        const errorResponse = {
            error: {
                code: 'AR_VISUALIZATION_FAILED',
                message: error.message,
                timestamp: new Date().toISOString()
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});

async function generateARMockup(supabaseUrl: string, serviceRoleKey: string, geminiApiKey: string, userId: string, data: any) {
    const {
        baseImageUrl,
        vehicleInfo,
        modifications,
        arSessionData,
        overlayPreferences
    } = data;

    console.log('Generating AR mockup for vehicle:', vehicleInfo);

    // Validate input
    if (!baseImageUrl || !vehicleInfo || !modifications) {
        throw new Error('Base image URL, vehicle info, and modifications are required');
    }

    // Generate detailed AR overlay instructions using Gemini
    let overlayInstructions = null;
    if (geminiApiKey) {
        try {
            const prompt = `
Analyze this automotive modification request and provide detailed AR overlay positioning instructions:

**VEHICLE INFO:**
- Year: ${vehicleInfo.year}
- Make: ${vehicleInfo.make}
- Model: ${vehicleInfo.model}
- Current Engine: ${vehicleInfo.currentEngine || 'Stock'}

**MODIFICATIONS:**
${JSON.stringify(modifications, null, 2)}

**AR SESSION DATA:**
- Camera Position: ${JSON.stringify(arSessionData?.cameraPosition || {})}
- Lighting Conditions: ${arSessionData?.lighting || 'auto'}
- Vehicle Angle: ${arSessionData?.vehicleAngle || 'front-quarter'}

Provide AR overlay instructions in JSON format:
{
  "overlayElements": [
    {
      "type": "engine_bay",
      "position": {"x": 0.0, "y": 0.0, "z": 0.0},
      "scale": 1.0,
      "rotation": {"x": 0, "y": 0, "z": 0},
      "modifications": ["specific visual changes"]
    }
  ],
  "visualEffects": {
    "lighting": "enhanced|realistic|dramatic",
    "reflections": true,
    "shadows": true,
    "materialProperties": {
      "metallic": 0.8,
      "roughness": 0.2
    }
  },
  "compatibility": {
    "feasibility": "excellent|good|challenging",
    "visualAccuracy": 0.95
  }
}`;

            const geminiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiApiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{ text: prompt }]
                    }],
                    generationConfig: {
                        temperature: 0.3,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 1024
                    }
                })
            });

            if (geminiResponse.ok) {
                const geminiData = await geminiResponse.json();
                const aiText = geminiData.candidates[0].content.parts[0].text;
                
                try {
                    const jsonMatch = aiText.match(/\{[\s\S]*\}/);
                    if (jsonMatch) {
                        overlayInstructions = JSON.parse(jsonMatch[0]);
                    }
                } catch (parseError) {
                    console.error('Failed to parse Gemini response:', parseError);
                    overlayInstructions = {
                        overlayElements: [],
                        visualEffects: { lighting: 'realistic' },
                        compatibility: { feasibility: 'good', visualAccuracy: 0.8 }
                    };
                }
            }
        } catch (geminiError) {
            console.error('Gemini API error:', geminiError);
        }
    }

    // Create mockup data structure
    const mockupData = {
        baseImage: baseImageUrl,
        vehicleInfo,
        modifications,
        arSessionData: arSessionData || {},
        overlayInstructions,
        overlayPreferences: overlayPreferences || {},
        generatedAt: new Date().toISOString(),
        version: '1.0'
    };

    // Save AR mockup to database
    const arMockupData = {
        user_id: userId,
        base_image_url: baseImageUrl,
        mockup_data: mockupData,
        vehicle_info: vehicleInfo,
        modifications: modifications,
        ar_session_data: arSessionData || {},
        processing_status: 'completed',
        is_public: true,
        created_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/ar_mockups`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(arMockupData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to save AR mockup: ${errorText}`);
    }

    const savedMockup = await response.json();

    return {
        mockup: savedMockup[0],
        overlayInstructions,
        message: 'AR mockup generated successfully',
        arCompatibility: overlayInstructions?.compatibility || { feasibility: 'good', visualAccuracy: 0.8 }
    };
}

async function saveARSession(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const {
        sessionDuration,
        mockupsGenerated,
        deviceInfo,
        arFeaturesUsed,
        sessionRating,
        feedback
    } = data;

    const sessionData = {
        user_id: userId,
        session_duration: sessionDuration || 0,
        mockups_generated: mockupsGenerated || 0,
        device_info: deviceInfo || {},
        ar_features_used: arFeaturesUsed || [],
        session_rating: sessionRating || null,
        feedback: feedback || null,
        created_at: new Date().toISOString()
    };

    const response = await fetch(`${supabaseUrl}/rest/v1/ar_sessions`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        },
        body: JSON.stringify(sessionData)
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to save AR session: ${errorText}`);
    }

    const session = await response.json();

    return {
        session: session[0],
        message: 'AR session saved successfully'
    };
}

async function processARImage(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { mockupId, imageProcessingOptions } = data;

    // Get mockup data
    const mockupResponse = await fetch(`${supabaseUrl}/rest/v1/ar_mockups?id=eq.${mockupId}&user_id=eq.${userId}`, {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    const mockups = await mockupResponse.json();
    if (mockups.length === 0) {
        throw new Error('Mockup not found');
    }

    const mockup = mockups[0];

    // Simulate image processing (in real implementation, this would call an image processing service)
    const processedImageUrl = `${mockup.base_image_url}?processed=${Date.now()}`;

    // Update mockup with processed image
    const updateResponse = await fetch(`${supabaseUrl}/rest/v1/ar_mockups?id=eq.${mockupId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            generated_preview_url: processedImageUrl,
            processing_status: 'completed',
            updated_at: new Date().toISOString()
        })
    });

    if (!updateResponse.ok) {
        const errorText = await updateResponse.text();
        throw new Error(`Failed to update mockup: ${errorText}`);
    }

    return {
        mockupId,
        processedImageUrl,
        processingOptions: imageProcessingOptions,
        message: 'Image processed successfully'
    };
}

async function getARMockups(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { isPublic = true, limit = 20, offset = 0 } = data;

    let query = `${supabaseUrl}/rest/v1/ar_mockups?`;
    const params = new URLSearchParams();
    
    if (isPublic) {
        params.append('is_public', 'eq.true');
    } else {
        params.append('user_id', `eq.${userId}`);
    }
    
    params.append('order', 'created_at.desc');
    params.append('limit', limit.toString());
    params.append('offset', offset.toString());

    const response = await fetch(query + params.toString(), {
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey
        }
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to fetch AR mockups: ${errorText}`);
    }

    const mockups = await response.json();

    return {
        mockups,
        count: mockups.length,
        hasMore: mockups.length === limit
    };
}

async function updateMockupVisibility(supabaseUrl: string, serviceRoleKey: string, userId: string, data: any) {
    const { mockupId, isPublic } = data;

    const response = await fetch(`${supabaseUrl}/rest/v1/ar_mockups?id=eq.${mockupId}&user_id=eq.${userId}`, {
        method: 'PATCH',
        headers: {
            'Authorization': `Bearer ${serviceRoleKey}`,
            'apikey': serviceRoleKey,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            is_public: isPublic,
            updated_at: new Date().toISOString()
        })
    });

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to update mockup visibility: ${errorText}`);
    }

    return {
        mockupId,
        isPublic,
        message: 'Mockup visibility updated successfully'
    };
}