Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { car, engine, checkType } = await req.json();
        
        if (!car || !engine) {
            throw new Error('Both car and engine information are required');
        }

        // Get Google Gemini API key from environment
        const geminiApiKey = Deno.env.get('GOOGLE_GEMINI_API_KEY');
        if (!geminiApiKey) {
            throw new Error('Google Gemini API key not configured');
        }

        // Prepare detailed prompt for Gemini AI
        const compatibilityPrompt = `
Analyze the engine swap compatibility between:

Vehicle: ${car.year} ${car.make} ${car.model}${car.generation ? ` (${car.generation})` : ''}
Target Engine: ${engine.name} (${engine.code}) - ${engine.displacement} ${engine.configuration}
Power: ${engine.power}, Torque: ${engine.torque}, Manufacturer: ${engine.manufacturer}

Please provide a comprehensive compatibility analysis in the following JSON format:
{
  "compatible": boolean,
  "confidence": number (70-100),
  "issues": ["array of known fitment issues"],
  "warnings": ["array of potential concerns"],
  "suggestions": ["array of recommendations and modifications needed"],
  "fitmentDifficulty": "Easy|Moderate|Difficult|Expert",
  "estimatedCost": "$X,XXX range for the swap",
  "regulatoryNotes": ["array of legal/emissions considerations"]
}

Consider factors like:
- Engine bay dimensions and clearance
- Transmission compatibility
- ECU and wiring requirements
- Mounting points and brackets
- Cooling system requirements
- Exhaust routing
- Power steering and AC compatibility
- Legal/emissions compliance
- Common known issues for this specific swap
- Cost estimates for parts and labor

Provide detailed, accurate information based on real-world engine swap knowledge.
`;

        // Call Google Gemini API
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent?key=${geminiApiKey}`;
        
        const geminiResponse = await fetch(geminiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: compatibilityPrompt
                    }]
                }],
                generationConfig: {
                    temperature: 0.3,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 2048,
                },
                safetySettings: [
                    {
                        category: "HARM_CATEGORY_HARASSMENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_HATE_SPEECH",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    },
                    {
                        category: "HARM_CATEGORY_DANGEROUS_CONTENT",
                        threshold: "BLOCK_MEDIUM_AND_ABOVE"
                    }
                ]
            })
        });

        if (!geminiResponse.ok) {
            const errorText = await geminiResponse.text();
            console.error('Gemini API error:', errorText);
            throw new Error(`Gemini API request failed: ${geminiResponse.status}`);
        }

        const geminiData = await geminiResponse.json();
        
        if (!geminiData.candidates || geminiData.candidates.length === 0) {
            throw new Error('No response from Gemini AI');
        }

        const responseText = geminiData.candidates[0].content.parts[0].text;
        
        // Extract JSON from the response
        let compatibilityResult;
        try {
            // Try to find JSON in the response
            const jsonMatch = responseText.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                compatibilityResult = JSON.parse(jsonMatch[0]);
            } else {
                throw new Error('No valid JSON found in response');
            }
        } catch (parseError) {
            console.error('Failed to parse Gemini response as JSON:', parseError);
            // Fallback: create structured response from text
            compatibilityResult = {
                compatible: responseText.toLowerCase().includes('compatible'),
                confidence: 75,
                issues: [],
                warnings: [],
                suggestions: [responseText],
                fitmentDifficulty: 'Moderate',
                estimatedCost: '$3,000-$8,000',
                regulatoryNotes: ['Professional installation recommended']
            };
        }

        // Store the compatibility check in database for learning
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        
        if (supabaseUrl && serviceRoleKey) {
            try {
                const insertResponse = await fetch(`${supabaseUrl}/rest/v1/compatibility_knowledge_base`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        car_make: car.make,
                        car_model: car.model,
                        car_year: car.year,
                        car_generation: car.generation,
                        engine_code: engine.code,
                        engine_name: engine.name,
                        compatibility_data: compatibilityResult,
                        ai_response: responseText,
                        created_at: new Date().toISOString()
                    })
                });
                
                if (!insertResponse.ok) {
                    console.warn('Failed to store compatibility data:', await insertResponse.text());
                }
            } catch (dbError) {
                console.warn('Database storage error:', dbError);
            }
        }

        return new Response(JSON.stringify({
            data: {
                compatibility: compatibilityResult,
                aiResponse: responseText,
                timestamp: new Date().toISOString()
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('AI compatibility check error:', error);
        
        const errorResponse = {
            error: {
                code: 'AI_COMPATIBILITY_CHECK_FAILED',
                message: error.message
            }
        };
        
        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});