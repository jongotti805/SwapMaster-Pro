Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { currentEngine, targetEngine, modifications, vehicleInfo } = await req.json();

        if (!currentEngine || !targetEngine) {
            throw new Error('Current engine and target engine are required');
        }

        // Get user from auth header (optional)
        let userId = null;
        const authHeader = req.headers.get('authorization');
        if (authHeader) {
            try {
                const token = authHeader.replace('Bearer ', '');
                const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'apikey': serviceRoleKey
                    }
                });
                if (userResponse.ok) {
                    const userData = await userResponse.json();
                    userId = userData.id;
                }
            } catch (authError) {
                console.log('Auth error, proceeding as anonymous:', authError);
            }
        }

        // Get environment variables
        const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

        if (!openaiApiKey || !supabaseUrl || !serviceRoleKey) {
            throw new Error('Missing required environment variables');
        }

        // Create comprehensive prompt for swap guide generation
        const promptTemplate = `Create a detailed, step-by-step engine swap guide for the following conversion:

SWAP DETAILS:
- Current Engine: ${currentEngine}
- Target Engine: ${targetEngine}
- Additional Modifications: ${modifications || 'None specified'}
- Vehicle Information: ${JSON.stringify(vehicleInfo || {})}

Please provide a comprehensive guide that includes:

1. COMPATIBILITY ANALYSIS
   - Physical compatibility assessment
   - Known issues and challenges
   - Compatibility score (0-100)

2. REQUIRED PARTS LIST
   - Engine mounts and brackets
   - Wiring harnesses and adapters
   - Fuel system components
   - Exhaust system modifications
   - ECU and tuning requirements
   - Transmission compatibility
   - Cooling system modifications
   - Include specific part numbers when possible

3. DETAILED INSTALLATION STEPS
   - Pre-installation preparation
   - Removal of original engine
   - Modification requirements
   - Installation of new engine
   - Wiring and electrical connections
   - Fuel system setup
   - Exhaust routing
   - Final assembly and testing

4. ESTIMATED COSTS
   - Parts cost breakdown
   - Labor time estimates
   - Total project cost range

5. DIFFICULTY ASSESSMENT
   - Skill level required (Beginner/Intermediate/Advanced)
   - Special tools needed
   - Estimated completion time

6. PERFORMANCE EXPECTATIONS
   - Expected power gains
   - Torque improvements
   - Potential issues to watch for

7. TUNING AND SETUP
   - ECU programming requirements
   - Fuel mapping considerations
   - Break-in procedures

Provide specific, actionable advice that a mechanic could follow. Include safety warnings and best practices throughout the guide.`;

        // Create initial database record
        const insertResponse = await fetch(`${supabaseUrl}/rest/v1/dynamic_swap_guides`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
            },
            body: JSON.stringify({
                user_id: userId,
                current_engine: currentEngine,
                target_engine: targetEngine,
                modifications: modifications || '',
                vehicle_info: vehicleInfo || {},
                generated_guide: 'Generating...',
                generation_status: 'pending',
                is_public: true
            })
        });

        if (!insertResponse.ok) {
            const errorText = await insertResponse.text();
            throw new Error(`Failed to create swap guide record: ${errorText}`);
        }

        const guideRecord = await insertResponse.json();
        const guideId = guideRecord[0]?.id;

        try {
            // Generate guide using OpenAI
            const guideResponse = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${openaiApiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'gpt-4',
                    messages: [
                        {
                            role: 'system',
                            content: 'You are an expert automotive technician with 20+ years of experience in engine swaps. Provide detailed, accurate, and practical advice for engine conversions. Always include safety warnings and realistic cost estimates.'
                        },
                        {
                            role: 'user',
                            content: promptTemplate
                        }
                    ],
                    max_tokens: 4000,
                    temperature: 0.3
                })
            });

            if (!guideResponse.ok) {
                const errorData = await guideResponse.json();
                throw new Error(`OpenAI API error: ${errorData.error?.message || 'Unknown error'}`);
            }

            const guideData = await guideResponse.json();
            const generatedGuide = guideData.choices[0]?.message?.content;

            if (!generatedGuide) {
                throw new Error('No guide generated by OpenAI');
            }

            // Parse the generated guide to extract structured data
            const compatibilityMatch = generatedGuide.match(/compatibility score[:\s]*(\d+)/i);
            const compatibilityScore = compatibilityMatch ? parseInt(compatibilityMatch[1]) / 100 : 0.5;

            const difficultyMatch = generatedGuide.match(/skill level required[:\s]*(beginner|intermediate|advanced)/i);
            const difficultyLevel = difficultyMatch ? difficultyMatch[1].toLowerCase() : 'intermediate';

            const timeMatch = generatedGuide.match(/estimated completion time[:\s]*([^\n]+)/i);
            const estimatedTime = timeMatch ? timeMatch[1].trim() : '2-4 weeks';

            const costMatch = generatedGuide.match(/total project cost[:\s]*\$?([\d,]+)\s*-\s*\$?([\d,]+)/i);
            const estimatedCost = costMatch ? parseFloat(costMatch[2].replace(/,/g, '')) : null;

            // Extract required parts (basic parsing)
            const partsSection = generatedGuide.match(/REQUIRED PARTS LIST[\s\S]*?(?=\n\d+\.|$)/i);
            const requiredParts = [];
            if (partsSection) {
                const parts = partsSection[0].match(/- ([^\n]+)/g) || [];
                parts.forEach(part => {
                    const cleanPart = part.replace(/^- /, '').trim();
                    if (cleanPart) {
                        requiredParts.push({
                            name: cleanPart,
                            category: 'General',
                            required: true
                        });
                    }
                });
            }

            // Update database record with generated guide
            const updateResponse = await fetch(`${supabaseUrl}/rest/v1/dynamic_swap_guides?id=eq.${guideId}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json',
                    'Prefer': 'return=representation'
                },
                body: JSON.stringify({
                    generated_guide: generatedGuide,
                    required_parts: requiredParts,
                    estimated_cost: estimatedCost,
                    estimated_time: estimatedTime,
                    difficulty_level: difficultyLevel,
                    compatibility_score: compatibilityScore,
                    generation_status: 'completed'
                })
            });

            if (!updateResponse.ok) {
                const errorText = await updateResponse.text();
                console.error('Failed to update swap guide record:', errorText);
            }

            return new Response(JSON.stringify({
                data: {
                    guideId,
                    guide: generatedGuide,
                    requiredParts,
                    estimatedCost,
                    estimatedTime,
                    difficultyLevel,
                    compatibilityScore,
                    status: 'completed'
                }
            }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });

        } catch (generationError) {
            // Update database record with error
            await fetch(`${supabaseUrl}/rest/v1/dynamic_swap_guides?id=eq.${guideId}`, {
                method: 'PATCH',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    generation_status: 'failed',
                    error_message: generationError.message
                })
            });

            throw generationError;
        }

    } catch (error) {
        console.error('Dynamic swap guide generation error:', error);

        const errorResponse = {
            error: {
                code: 'SWAP_GUIDE_GENERATION_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});